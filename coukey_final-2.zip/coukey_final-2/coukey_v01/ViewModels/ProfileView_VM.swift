//
//  ProfileView_VM.swift
//  coukey_v01
//
//  Created by Student on 18.06.23.
//

import Foundation
//TODO: thats probabl all auth vm content... dont do this extra i guess
//maybe acutally do it to not blow up our auth_vm even more
//TODO: just include this into the new Profil_View
class ProfileView_VM : ObservableObject {
    
    @Published var codeSent : Bool = false
    @Published var verified : Bool = false
    @Published var currentNumber : String = ""
    @Published var confirmCode : String = ""
    //TODO: would be nice to have this type of input field
    //[7][4][2][3][1] ->
    @Published var digit0 : String = ""
    @Published var digit1 : String = ""
    @Published var digit2 : String = ""
    @Published var digit3 : String = ""
    @Published var digit4 : String = ""
    @Published var digit5 : String = ""
    
    
    //MARK : send the Verification Code to the users Phone number
    //TODO : need to check for Phone number otherwise user needs to enter his number
    func sendVerification(){
        Task {
            do{
                 let token = try await AppwriteService.shared.account.createPhoneVerification()
                DispatchQueue.main.async {
                    self.codeSent = true
                }
                    
            } catch {
                print("verification not send")
            }
            
        }
    }
    
    
    func confirmVerification(){
        Task {
            do{
            let current = try await AppwriteService.shared.account.get()
            let currentUserId = current.id
            self.currentNumber = current.phone
            print("CurrentUserId")
            print(currentUserId)
                print(current.email)
            let token = try await AppwriteService.shared.account.updatePhoneVerification(userId: currentUserId, secret: self.confirmCode)
            print(token)
            } catch {
                print("confirmation failed")
                
            }
        }
        
    }
    
}
