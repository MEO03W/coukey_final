//
//  CoukingView_VM.swift
//  coukey_v01
//
//  Created by Student on 09.07.23.
//

import Foundation

class CoukingView_VM : ObservableObject {
    
    @Published var currentRecipe : Result
    @Published var servingsCount : Int = 0
    
    init(currentRecipe : Result){
        self.currentRecipe = currentRecipe
    }
    
    func getExtendedIngredientList() -> [EdIngredient]{
        let currentIngredients : [EdIngredient] = currentRecipe.extendedIngredients
        var ingredientList : [EdIngredient] = []
        
        for ingredient in currentIngredients {
            
            let amount : Double = ingredient.amount / Double(currentRecipe.servings) * Double(servingsCount)
            let amountMetric : Double = ingredient.measures!.metric.amount / Double(currentRecipe.servings) * Double(servingsCount)
            let amountUs : Double = ingredient.measures!.us.amount / Double(currentRecipe.servings) * Double(servingsCount)
            
            
            let measures : Measures = Measures(us: Metric(amount: amountUs, unitShort: ingredient.unitShort ?? "", unitLong: ingredient.unitLong ?? ""), metric: Metric(amount: amountMetric, unitShort: ingredient.measures?.metric.unitShort ?? "", unitLong: ingredient.measures?.metric.unitLong ?? ""))
            
           
            ingredientList.append(EdIngredient(id: ingredient.id, aisle: ingredient.aisle, image: ingredient.image, name: ingredient.name, nameClean: ingredient.nameClean, original: ingredient.original, originalName: ingredient.originalName, amount: amount, unit: ingredient.unit, meta: ingredient.meta, measures: measures, unitLong: ingredient.unitLong ?? "", unitShort: ingredient.unitShort ?? "", extendedName: ingredient.extendedName ?? ""))
            
                
        }
        
        return  ingredientList
    }
    
    
    
}
