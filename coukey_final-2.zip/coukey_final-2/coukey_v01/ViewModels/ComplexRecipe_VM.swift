//
//  ComplexRecipe_VM.swift
//  coukey_v01
//
//  Created by Student on 29.06.23.
//

import Foundation

class ComplexRecipe_VM : ObservableObject {
    //
    //lets create a state managment for our viewmodel
    //where we could indicate if our viewmodel is currently loading new infos or if it failed or succeeded
    //MARK: state cases
    enum State {
        case idle
        case loading
        case failed // could have an (error)
        case loaded //could have the actual object which was loaded (MergedRecipeResponseList)
    }
    
    /**
     * lets store that later in different manner
     * can be done better with the with query operation from Url data task ?
     */
    let api_url = "https://api.spoonacular.com/recipes/complexSearch?"
    let instructionsParam = "&instructionsRequiered=true"
    let addInformation = "&addRecipeInformation=true"
    //let search_params = "information?apiKey="
    let api_key = "367e4a8def0b4fbd92d793093f96a81c"
    //Paul: 9478e1b5681a4a7699217dcfb40f9eda
    //Fynn: 367e4a8def0b4fbd92d793093f96a81c
    //Lucas c6e600edba0c4e7abdcc1efc5cadd1a4
        
    //
    //lepaul : "9478e1b5681a4a7699217dcfb40f9eda"
    
    
    /**
     * our Published variables which are binded by our views
     */
    
    //@Published var reciperesponse: RecipeResponse?
    //@Published var recipeInfoList : [RecipeInfo]?
    //@Published var recipeInforesponse: RecipeInfo?
    //@Published var isLoading: Bool = false;
    @Published var reciperesponse : Recipes?
    @Published var state = State.idle
    
    /**
     * our function / methods which provide business logic
     * here: lets try to fetch the recipeInfos we need e.g. steps, serving, ingredients and serving/cooking time, tags
     * checkout the RecipeInfoModel (is for single recipeinfo)
     */
    
    init(){
        
        //fetch recipes and infos on init once 
        //fetchAllRecipeWithInfo()
        fetchRecipeInfos(offSet : 0)
    }
   
    /* that was the attempt to do everything myself,
       bc i'm silly and can't read the docs right . . .
    func fetchAllRecipeWithInfo() {
        self.state = .loading
        //url string for the fetching of 10 recipes
        let recipe_url = "https://api.spoonacular.com/recipes/complexSearch?apiKey="
        //url string for fetching the details of a bulk of recipes
        let details_url = "https://api.spoonacular.com/recipes/informationBulk?ids="
        //the api Key keyword
        let api_KeyWord = "apiKey="
        //the part for the url which tells that we require recipes with instructions
        let instructionsKey = "&instructionsRequired=true&"
        //our current used apiKey
        let api_key = "9478e1b5681a4a7699217dcfb40f9eda"
   
        //other vars we need for temp storing
        //the list of 10 Recipes with title,imd,id,imgType
        var recipeListComplex : RecipeResponse?
        //the list of the details of the 10 recipes
        var recipeInfoList : [RecipeInfo]?
        //the string we build with from the fetched ids of 10 simple recipes
        var paramString = ""
        //build out the url string
        let urlString = recipe_url+api_key+instructionsKey
        //check if we can create an URL object from the string, if not then return, exit the function
        guard let url = URL(string: urlString) else {
            return
        }
     
        //MARK: List Task - get 10 recipes
        //create the first task
        let recipeListTask = URLSession.shared.dataTask(with: url){ [weak self]
            data, response, error in
            
            if let data = data, let string = String(data: data, encoding: .utf8){
                print(string)
                do {
                    /**
                     * here: try to decode the received recipeinfo via the model and store it in published variable
                     * update the main queue because it is an update to the ui
                     * maybe we could check wether its really an ui update right now and if not: dont interrupt main queue
                     */
                    let reciperesponse = try JSONDecoder().decode(RecipeResponse.self,from: data)
                    recipeListComplex = reciperesponse
                    
                    
                } catch {
                    //catch errors
                    //TODO: lets create error Messages that we send to the user
                    print("Decoder Error")
                    print(error)
                }
            }
            //lets create those params of recipe ids : key(ids) params(715534,7734890,9839842,903209)..
            recipeListComplex?.results.forEach{ recipe in
                paramString += String(recipe.id)
                paramString += ","
            }
            //make new url for infoBulk fetch
            print(paramString)
            
            let urlInfoString = details_url+paramString+"&"+api_KeyWord+api_key
            print(urlInfoString)
            guard let urlInfos = URL(string: urlInfoString) else {return}

            
            //MARK: Info Task - get recipe infos of the 10 recipes
            //create a task which fetches all the information from the recipes provided above
            let recipeInfoTask = URLSession.shared.dataTask(with: urlInfos){
                data, response, error in
                
                
                if let data = data, let string = String(data: data, encoding: .utf8){
                    print(string)
                    do {
                        /**
                         * here: try to decode the received recipeinfo via the model and store it in published variable
                         * update the main queue because it is an update to the ui
                         * maybe we could check wether its really an ui update right now and if not: dont interrupt main queue
                         */
                        
                        let reciperesponse = try JSONDecoder().decode([RecipeInfo].self,from: data)
                        recipeInfoList = reciperesponse
                        
                    } catch {
                        print("Decoder Error")
                        print(error)
                    }
                }
                //lets update the values and interrupt the main queue so we update the ui according to the new data
                DispatchQueue.main.async {
                    self?.reciperesponse = recipeListComplex
                    self?.recipeInfoList = recipeInfoList
                    self?.state = .loaded
                }
                
            }
            recipeInfoTask.resume()
            //inner Task end
            
            
        }
        recipeListTask.resume()
       //outerTask end
        
    }
    */
    //thats our old simple function dont need that anymore
    //MARK: fetch RECIPES
    func fetchRecipeInfos(offSet : Int) {
        
        //set the vm state to loading
        self.state = .loading
        
        //prepare the urlstring for fetching
        
        let urlString = "\(api_url)apiKey=\(api_key)\(instructionsParam)\(addInformation)&fillIngredients=true&offset=\(offSet)"
        print(urlString)
        
        //check if its possbile to create URL object from urlstring
        //if not return, exit function
        guard let url = URL(string: urlString) else {
            self.state = .failed
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self]
            data, response, error in
            
            if let data = data, let string = String(data: data, encoding: .utf8){
                print(string)
                do {
                    /**
                     * here: try to decode the received recipeinfo via the model and store it in published variable
                     * update the main queue because it is an update to the ui
                     * maybe we could check wether its really an ui update right now and if not: dont interrupt main queue
                     */
                    let reciperesponse = try JSONDecoder().decode(Recipes.self,from: data)
                    DispatchQueue.main.async {
                        if(offSet != 0){
                            print("##################################")
                            print(self?.reciperesponse?.results.count)
                            self?.reciperesponse?.results.append(contentsOf: reciperesponse.results)
                            print("##################################")
                            print(self?.reciperesponse?.results.count)
                            self?.state = .loaded
                        } else {
                            self?.reciperesponse = reciperesponse
                            //self?.recipes = reciperesponse.recipes
                            self?.state = .loaded
                        }
                    }
                } catch {
                    print("Decoder Error")
                    print(error)
                    //self.state = .failed
                }
                
            }
            
            
            if let response = response {
                print(response)
            }
            
            if let error = error {
                print("Spoonacular call not working")
                print(error)
            }
            
            
            
        }
        
        
        //state = .loaded
        task.resume()
       
  
        //isLoading = false
        //print(isLoading)
        
    }
    
    
}
