//
//  HomeView_VM.swift
//  coukey_v01
//
//  Created by Student on 08.06.23.
//

import Foundation
/**
 currently we are using the recipe short model in the homeview for testing
 later we want to use this viewmodel for the HOME View which is our likewise "mainview" (dont get it confused with the actual main view)
 */
class HomeView_VM : ObservableObject {
    
    //@Published var recipeArray<RecipeShortModel> = recipeArray()
    
    init(){
        
        
    }
    
    
    func fetchDatafromSpoonacular(){
        
        
        
    }
    
}
