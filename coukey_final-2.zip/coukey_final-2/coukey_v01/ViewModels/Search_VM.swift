//
//  Search_VM.swift
//  coukey_v01
//
//  Created by Student on 09.07.23.
//

import Foundation

class Search_VM : ObservableObject {
    
    
    @Published var searchedRecipeList : Recipes?
    @Published var searchString : String = ""
    
    private var alreadyFetchedList : Recipes
    
    init(existingList : Recipes){
        self.alreadyFetchedList = existingList
    }
    
//facade, use this to start the fetch
    func fetchData(){
        
    }
    
    private func fetchDataWithKeyword(){
        
        /* let search for our keyword in the title or dishtypes of the already fetched list
         * take those finds store it in a temp list and then fetch more recipes with the keyword
         * merge all results we found together
         */
       
        let searchedList = self.alreadyFetchedList.results.filter{$0.title.contains(searchString)}
        
        //should guard , couldnt get it running
        if searchedList != nil {
            self.searchedRecipeList = Recipes(results: searchedList, offset: 0 ,number: 0, totalResults: searchedList.count)
        }
        
        Task{
            let fetchList = try SpoonacularAPI.shared.fetchRecipes(offset: 0, query: searchString)
        }
        
    }
    
    
}
