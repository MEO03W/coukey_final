//
//  AuthViewModel.swift
//  testAppPrototyp
//
//  Created by Student on 16.06.23.
//
//rewrote everything to a new viewmodel -> everything
//from register and login merged viemodels
import Foundation
import Appwrite
import AppwriteModels

class Authentification_VM : ObservableObject {
    
    enum State {
        case idle
        case loading
        case failed
        case loaded
    }
    
    //MARK: lets better hold an user object later... if we have time
    @Published var isLoggedIn : Bool = false
    @Published var email = ""
    @Published var password = ""
    @Published var name = ""
    @Published var confirmPassword = ""
    
    @Published var currentUserId = ""
    @Published var currentUserName = ""
    @Published var currentUserPhone = ""
    @Published var currentUserMail = ""
    @Published var verified = false
    @Published var verifiedString = "false"
    @Published var errorMsg = ""
    @Published var confirmCode : String = ""
    @Published var confirmed : Bool = false 
    @Published private(set) var state = State.idle
    @Published var favorites : [Int] = []
    //@Published var currentUser : User
    //var realtime : Realtime
    
  
    
    
    init(){
       
       checkforSignedin()
     //setupRealtimeSubscription()
    }
    
    //MARK: sets up a realtime connection to Appwrite where we can listen on channels based of our user session
    /**
     * appwrite staff says listening on account channel might be bit tricky or buggy, so maybe dont use this for now acutally
     * we dont need it necessarily, but if we would have a parallel web application to this, then we could use the subsription to keep everything in sync
    */
private func setupRealtimeSubscription(){
        print("subscription func ")
        let realtime = Realtime(AppwriteService.shared.client)
        let subscription = realtime.subscribe(channels: ["account"], callback: { [weak self] response in
            print("realtime subscription")
            print(String(describing: response))
            DispatchQueue.main.async { //do it on the main queue because it will trigger a view update user/view interaction
                                     //always be prioritised //weak self
                self?.checkforSignedin()
            }
        })
    }
    
    //MARK: check if the user is signed in, sets the variables accordingly
func checkforSignedin() {

    self.state = .loading
        Task{
            
            do{
                let current = try await AppwriteService.shared.account.get()
                if current != nil && current.status {
                   
                    DispatchQueue.main.async {
                        self.isLoggedIn = true
                        self.currentUserId = current.id
                        self.currentUserName = current.name
                        self.currentUserMail = current.email
                        self.currentUserPhone = current.phone
                        print(current.email)
                        print(current.phone)
                        if current.phoneVerification || current.emailVerification {
                            self.verified = true
                            self.verifiedString = "true"
                        }
                        self.checkForFavoriteDocument()
                        self.state = .loaded

                    }
                }
            } catch {
                print(error.localizedDescription)
            }
            
        }
        
    }
    
    func updateAccount(){
        
        Task{
            
            do{
                let _ = try await AppwriteService.shared.account.updateName(name: self.currentUserName)
                let _ = try await AppwriteService.shared.account.updateEmail(email: self.currentUserMail, password: self.password)
                let _ = try await AppwriteService.shared.account.updatePhone(phone: self.currentUserPhone, password: self.password)
            } catch {
              
                print(error.localizedDescription)
                print("Update declined")
                print("be sure to fillout the fields.. and type in your password for confirmation!!")
                    
            }
            
        }
        
    }
    
    private func updateCredsAndAccount(){
        //lets check which fields differ
        //lets update them
        //but should validate before!
    }
    
    //MARK: calls the create a user function : facade
    func register() {
       createUser()
    }
    //MARK : create a user
private func createUser() {
    state = .loading
        let createUserTask = Task{
                   do {
                       let user = try await AppwriteService.shared.account.create(
                        userId: ID.unique(),
                        email: self.email,
                        password: self.password,
                        name: self.name
                    )
                       print("created")
                       print(user)
                    
                    } catch {
                        print("There occurred an error")
                    }
            DispatchQueue.main.async {
                self.state = .loaded
            }
                //create a new favorites document on register so the user has one
                //usually i would do this on my backend
                  createNewFavoriteDocument()
               }
        
     }
    //Mark : login user : facade
    func login(){
        print("called login")
        self.state = .loading
        let sessionTask = Task{
            await createUserSession()
            self.state = .loaded
        }
       
       
            
        
    }
   // MARK: create an user session , renew the realtime subscription and check if we logged in
private func createUserSession() async{
        do {
            print(self.email)
            print(self.password)
            //using the singleton AppwriteClient we created with AppwriteClient.shared.*
            let session = try await AppwriteService.shared.account.createEmailSession(email: self.email, password: self.password)
            print("Login successful")
            
            print("try to renew subsription")
            setupRealtimeSubscription()
            checkforSignedin()
            
        } catch {
            print(error.localizedDescription)
        }
    }
   
    //MARK: logout user on all devices
    func logout_all(){
        deleteUserSession(allDevices: true)
    }
    
    // MARK : LOGOUT a user
    func logout(){
        
        deleteUserSession(allDevices: false)
    }
    // MARK: Delete all user sessions of a user, like logout all devices
   private func deleteUserSession(allDevices:Bool) {
        Task{
            do{
                if allDevices {
                    //all sessions
                   let _ = try await AppwriteService.shared.account.deleteSessions()
                } else {
                   let _ = try await AppwriteService.shared.account.deleteSession(sessionId: "current")
                }
                
                DispatchQueue.main.async {
                    self.isLoggedIn = false
                    self.currentUserId = ""
                    self.password = ""
                    self.email = ""
                    self.currentUserMail = ""
                }
            } catch {
                print("Logout not possible")
            }
            
        }
    }
    
    //MARK: verify MAIL
    func verifyByEmail(){
        Task{
            do{
                let _ = try await AppwriteService.shared.account.createVerification(url: "cloud.appwrite.io")
            } catch {
                print("Couldnt init mail verification ")
                print(error.localizedDescription)
            }
        }
    }
    //MARK: verify Phone
    func verifyByPhone(){
        Task{
            do{
                let _ = try await AppwriteService.shared.account.createPhoneVerification()
            } catch {
                print("Phone verification couldnt be initialized")
                print("Check if you have typed in a valid phone number")
            }
        }
    }
    
    func confirmVerification(){
        
        Task{
            
            do{
                let token = try await AppwriteService.shared.account.updatePhoneVerification(userId: self.currentUserId, secret: confirmCode)
                
                DispatchQueue.main.async {
                    self.confirmed = true
                    self.verified = true
                }
                
            } catch {
                print(error.localizedDescription)
            }
        }
        
    }
    
    //MARK: faves
    //TODO: favorites logic
 
    //check if our favorite document is existing
    //
    private func checkForFavoriteDocument() {
       
        //TODO: create task returns, check for the task value and then create a document if necessary
        let checkerTask = Task {
            
            do {
                 let document = try await AppwriteService.shared.databases.getDocument(
                    databaseId: "648f5b2a03fdce12ba37", //coukey_dev
                    collectionId: "64ac67c9a346e3eefd82",//favos
                    documentId: currentUserId
                )
                
                
                //TODO: make this work pls ls ls pls pls
                //print(document.data)
                if document.data.isEmpty {
                    print("the favorites document is empty ")
                } else {
                    
                    if let recipeIDValue = document.data["recipeID"]?.value as? [Any] {
                        if let recipeIDs = recipeIDValue as? [Int] {
                            DispatchQueue.main.async {
                                self.favorites = recipeIDs
                            }
                        } else {
                            print("Recipe ID not found or has an incompatible type")
                        }
                    } else {
                        print("Recipe ID not found or has an incompatible type")
                    }
                }
            } catch {
                print(error.localizedDescription)
                if error.localizedDescription == "Document with the requested ID could not be found." {
                    createNewFavoriteDocument()
                }
            }
        }
        
    }
    //create a document
    private func createNewFavoriteDocument() {
        Task {
            
            do {
                
//                let jsonData = try JSONSerialization.data(withJSONObject: self.data)
//                let jsonString = String(data: jsonData,encoding: .utf8)
//                print(jsonString)
                let payload: [String:Any] = [
                    "recipeID" : []
                ]
               let jsonData = try JSONSerialization.data(withJSONObject: payload)
               let jsonString = String(data: jsonData,encoding: .utf8)
               print(jsonString)
                
                let _ = try await AppwriteService.shared.databases.createDocument(
                    databaseId: "648f5b2a03fdce12ba37", //coukey_dev
                    collectionId: "64ac67c9a346e3eefd82", //favorites
                    documentId: currentUserId,
                    data: jsonString,
                    permissions: [
                        //Only the user gets access to his own favorites granted
                        Permission.read(Role.user(currentUserId)),
                        Permission.update(Role.user(currentUserId)),
                        Permission.delete(Role.user(currentUserId)),
                        Permission.delete(Role.users())
                        // Permission.delete(Role.user("64907eaa9ab02c0495bf")) //admin team
                        
                    ]
                )
                
            }
            catch {
                print("NOT ABLE TO CREATE FAVORITE DOCUMENT")
                print(error.localizedDescription)
            }
            
        }
    }
    //we should throw something, maybe the updated list, or the document
    private func updateFovoritesDocument() -> Bool{
        //lets check if our task did run successfully
        var sucess : Bool = false
        let payload :[String:Any] = [
            "recipeID" : self.favorites ?? []
        ]
        Task{
            
            do{
                let jsonData = try JSONSerialization.data(withJSONObject: payload)
                let jsonString = String(data: jsonData,encoding: .utf8)
                print(jsonString)
                let _ = try await AppwriteService.shared.databases.updateDocument(
                    databaseId: "648f5b2a03fdce12ba37", //coukey_dev
                    collectionId: "64ac67c9a346e3eefd82", //favorites
                    documentId: currentUserId,
                    data: jsonString
                )
            } catch {
                print(error.localizedDescription)
                //Task.isCancelled = true
                
            }
            
        }
        return true
    }
    
    func deleteFavoriteFromTheList(recipeId : Int){
        //TODO: remove an item of the favorites list
        print("DELETE FORM LIST METHOD")
        if let index = self.favorites.firstIndex(of: recipeId){
            self.favorites.remove(at: index)
        }
        //self.favorites.remove(at: favorites.firstIndex(of: recipeId)! )
        print("addFavorite: \(recipeId) allFaves: \(String(describing: favorites))")
        let _ = updateFovoritesDocument()
    }
    
    func addNewFavorite(recipeId: Int){
        //TODO: new favorite
        print("ADD TO LIST METHOD")
        self.favorites.append(recipeId)
        print("addFavorite: \(recipeId) allFaves: \(String(describing: favorites))")
        let _ = updateFovoritesDocument()
    }
    
    func recipeIsFavorite(recipeId: Int) -> Bool {
        
        if let index = self.favorites.firstIndex(of: recipeId){
            return true
        } else {
            return false
        }
    }
    
    //should check for my return value and or await some error handling stuff
    //should work for now
    
    //TODO: real validation maybe with regExp patterns
    func validate(){
        guard !email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              !password.trimmingCharacters(in: .whitespaces).isEmpty else {
                  print("inside valid block ")
            return
        }
    }
    
    
    
    
}
