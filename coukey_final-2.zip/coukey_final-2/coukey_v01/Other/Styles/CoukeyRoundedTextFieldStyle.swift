//
//  CoukeyRoundedTextFieldStyle.swift
//  coukey_v01
//
//  Created by Student on 25.05.23.
//


import SwiftUI


struct CoukeyRoundedTextFieldStyle: TextFieldStyle {
    //Textfield global styling component
    //Textfield styleguide appliance on insertion in sub compononents
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding(5)
            .background(Color.white)
            .multilineTextAlignment(.center)
            
          
            .foregroundColor(Color(red: 0.934, green: 0.436, blue: 0.436))
            .cornerRadius(20)
            .shadow(color: .gray, radius: 1)
    }
}
