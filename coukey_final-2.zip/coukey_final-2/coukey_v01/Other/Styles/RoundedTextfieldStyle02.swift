//
//  CoukeyRoundedTextFieldStyle.swift
//  coukey_v01
//
//  Created by Student on 25.05.23.
//


import SwiftUI



extension View {
    //Textfield global styling component
    //Textfield styleguide appliance on insertion in sub compononents
    func RoundedTextfieldStyle02() -> some View {
        self
            .padding(5)
            .background(Color.white)
            .multilineTextAlignment(.leading)
            .listRowSeparator(.hidden)
            
          
            .foregroundColor(Color(red: 0.934, green: 0.436, blue: 0.436))
            .cornerRadius(20)
            .overlay(
                                    RoundedRectangle(cornerRadius: 25)
                                        .stroke(Color("Lax"), lineWidth: 3)
                                )
    }
}

