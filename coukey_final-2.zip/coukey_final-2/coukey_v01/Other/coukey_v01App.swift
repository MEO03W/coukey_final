//
//  coukey_v01App.swift
//  coukey_v01
//
//  Created by Student on 18.05.23.
//

import SwiftUI

@main
struct coukey_v01App: App {

    /**
     *ENTRY POINT INTO THE WHOLE APPLICATION
     *CREATES AN ENVIRONMENT OBJECT FROM THE AUTH VIEW MODEL
     *WE WANT TO CHECK OUR AUTHENTICATION STATE EVERYWHERE IN THE APP 
     */
    
    let auth_vm = Authentification_VM()
    
        init() {
            let center = UNUserNotificationCenter.current()
            center.requestAuthorization(options: [.alert, .sound, .badge]) { result, error in
                if let error = error {
                    print(error)
                }
            }
        }

    var body: some Scene {
        WindowGroup {
            MainView().environmentObject(auth_vm)
        }
    }
}
