//
//  AppwriteClient.swift
//  coukey_v01
//
//  Created by Student on 07.06.23.
//

//TODO finalise the outsourced client
//TODO make it thread safe - with synchronising
/**
 The AppwriteClient is a service Client which is implemented as a 'Singleton'
 there is only 1 instance in the whole project of the client / account
 that is necessary that we cant have different sessions and the realtime features are working properly
  
  it has a private init so its only able to create itself
 */
import Foundation
import Appwrite

class AppwriteService {
    
    static let shared = AppwriteService()
    
    let client: Client
    let account: Account
    let databases : Databases
    
    private init(){
            client = Client()
                .setEndpoint("https://cloud.appwrite.io/v1")
                .setProject("64806c3e5338741442bd")
                .setSelfSigned(true)
            account = Account(client)
            databases = Databases(client)
            }
    }
   
    
    

