//
//  SpoonacularAPI.swift
//  coukey_v01
//
//  Created by Student on 09.07.23.
//

//tried to write a service which is capabble of fetching
//couldnt verify its full functionality in time
//therfore didnt use it
import Foundation
import Combine
class SpoonacularAPI {
    static let shared = SpoonacularAPI()
    
    func fetchRecipes(offset: Int, query : String) -> AnyPublisher<Result , Error> {
        var components = URLComponents(string: "https://api.spoonacular.com")!
        components.queryItems = [
            URLQueryItem(name:"offset", value: "\(offset)"),
            URLQueryItem(name:"query", value:"\(query)")
        ]
        
        let request = URLRequest(url:components.url!, timeoutInterval: 10)
        return URLSession.shared.dataTaskPublisher(for: request)
            .map(\.data)
            .decode(type:Result.self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
        
    }
}
