//
//  RecipeShortTableView.swift
//  coukey_v01
//
//  Created by Paul/Student on 20.05.23.
//
//
import SwiftUI

struct RecipeShortTableView: View {
    var body: some View {
        
        VStack{
            
        }
        Button{} label: {
            Text("Test")
        }
        
        
    }
}

struct RecipeShortTableView_Previews: PreviewProvider {
    static var previews: some View {
        RecipeShortTableView()
    }
}
