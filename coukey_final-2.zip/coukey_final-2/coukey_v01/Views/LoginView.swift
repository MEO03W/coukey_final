//
//  LoginView.swift
//  coukey_v01
//
//  Created by Student on 18.05.23.
//
//
import SwiftUI

struct LoginView: View {
    
    //Authentification viewmodel import
    @EnvironmentObject var viewModel : Authentification_VM
    
    init(){
        UITableView.appearance().backgroundColor = .clear
    }
    
    //Animation variables
    @State var opacity = 0.0
    @State var size = 0.0
    @State var size2 = 0.0
    @State var opacity2 = 0.0
    
    
    var body: some View {
       NavigationView{
        
        //Login view with stepped timed laod animation
        //Imitates keyframe behavior
        VStack{
            //Header
            ZStack{
                Color.white
                    .ignoresSafeArea()
                Image("TextFrame")
                    .resizable()
                    .frame(width: 251, height: 187)
                    .scaleEffect(size)
                
                    //Animation call for "size" with according delay on appear
                    //Imitates Splash Screen with 1 Sec delay
                    //App needs some time to load according view when closing from logged in state
                    .onAppear{
                        withAnimation(.easeIn(duration: 0.3).delay(1.1)){
                            self.size = 1.0
                            
                        }
                    }

                VStack(alignment: .leading, spacing: -6){
                    Text("COUKEY")
                        .foregroundColor(Color("DarkLax"))
                        .font(.system(size:42, weight: (.bold)))
                    Text("Right")
                        .foregroundColor(Color("Lax"))
                        .font(.system(size:42, weight: (.regular)))
                        .multilineTextAlignment(.leading)
                        .lineLimit(0)
                        .padding(0.0)
                    Text("Now!")
                        .foregroundColor(Color("Lax"))
                        .font(.system(size:42, weight: (.regular)))
                        .multilineTextAlignment(.leading)
                        .lineLimit(0)
                        .padding(0.0)
                }
                .padding(0.0)
                .offset(x: -20, y: -18)
                .opacity(opacity)
                .onAppear{
                    //Animation call for "opacity" with according delay on appaear
                    withAnimation(.easeIn(duration: 0.3).delay(1.5)){
                        self.opacity = 1.0
                        
                    }
                }
                Image("CoukyLogo")
                    .resizable()
                    .frame(width: 111, height: 111)
                    .offset(x: 52, y: 21)
                    .scaleEffect(size2)
                    //Animation call for "size2" with according delay on appear
                    .onAppear{
                        withAnimation(.easeIn(duration: 0.2).delay(1.7)){
                            self.size2 = 1.0
                            
                        }
                    }
            }
            
            if let errorMessage = viewModel.errorMsg{
                Text(errorMessage)
            }
            VStack{
                Form{
                    TextField(
                     "Email Adresse",
                     text: $viewModel.email).padding(.leading, 10)
                        .RoundedTextfieldStyle02()
                         .autocapitalization(.none)
                         .disableAutocorrection(true)
                    SecureField("password",text :$viewModel.password).padding(.leading, 10)
                        .RoundedTextfieldStyle02()
                         
                     
                    CoukeyBUTTON(title: "Log in",background: Color("Purple"),action: viewModel.login)
                    
                    
                 }
                 //Footer Create account
                 VStack{
                     Text("No account yet ?")
                     
                     NavigationLink("Create one now", destination: RegisterView())
                         .foregroundColor(Color("Purple"))
                 }
            }.opacity(opacity2)
            
                //Animation call for "size2" with according delay on appear
                .onAppear{
                    withAnimation(.easeIn(duration: 0.2).delay(2.3)){
                        self.opacity2 = 1.0
                        
                    }
                }
                Spacer()
        }
        
    }
  }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
            .preferredColorScheme(.light)
    }
}
