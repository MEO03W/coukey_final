//
//  AppStart1.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 14.06.23.
//
//
import SwiftUI
struct AppStart1: View {
    @State private var selectedTab: Tab = .house
    @StateObject var cR_vm = ComplexRecipe_VM()
    var body: some View {

        //manages the tabbar
        //programatic navigation
        ZStack {
             VStack {
                 if selectedTab == .house {
                  
                     HomeView()
                         .environmentObject(cR_vm)
                   
                 } else if selectedTab == .dollarsign {
                     Text("Yumm Rewards")
                         .foregroundColor(Color("Lax"))
                     RewardView()
                 } else if selectedTab == .cart {
                     Text("Couking")
                         .foregroundColor(Color("Lax"))
                 } else if selectedTab == .magnifyingglass {
                 
                     SearchAndGridContentView()
                         .environmentObject(cR_vm)
                 } else if selectedTab == .person {
                     
                     Profile_View()
                         
                 }
                 Spacer()
                 TabBar(selectedTab: $selectedTab)
             }
             .edgesIgnoringSafeArea(.all)
         }.background(.white)

    }
}

struct AppStart1_Previews: PreviewProvider {
    static var previews: some View {
        AppStart1()
    }
}
