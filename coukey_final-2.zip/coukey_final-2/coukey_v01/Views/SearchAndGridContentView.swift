//
//  SearchAndGridContentView.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 05.07.23.
//

import SwiftUI
struct SearchAndGridContentView: View {
    @EnvironmentObject var cR_vm: ComplexRecipe_VM
    private var gridItemLayout = [GridItem(.flexible(), spacing: 20), GridItem(.flexible(), spacing: 0)]
    @State private var searchText = ""
    //return of the filtered Recipes
    var filteredRecipes: [Result] {
        if searchText.isEmpty {
            return cR_vm.reciperesponse?.results ?? []
        } else {
            return cR_vm.reciperesponse?.results.filter { $0.title.localizedCaseInsensitiveContains(searchText) } ?? []
        }
    }
    // Grid View w´with the Recipes from the Api 
    var body: some View {
        NavigationView {
            ScrollView {
                LazyVGrid(columns: gridItemLayout) {
                    ForEach(filteredRecipes, id: \.id) { result in
                        ZStack(alignment: .bottomLeading) {
                            NavigationLink(destination: CoukingView(currentRecipe: result)) {
                                URLImageView(urlString: "https://spoonacular.com/recipeImages/"+String(result.id)+"-556x370.jpg", data: nil)
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: UIScreen.main.bounds.width / 2, height: UIScreen.main.bounds.width / 2)
                                    .clipped()
                            }
                            HStack {
                                //HomeViewProfile(recipeName: result.title)
                            }
                            Spacer()
                            /* ReceptPopUp(recipeName: result.title, recipeTime: result.readyInMinutes) */
                        }
                    }
                }
            }
            .searchable(text: $searchText, prompt: "Looking for Yums?")
            .navigationBarTitleDisplayMode(.inline)
        }
        .accentColor(Color("Lax"))
    }
}





struct SearchAndGridContentView_Previews: PreviewProvider {
    static var previews: some View {
        SearchAndGridContentView()
    }
}

                        
