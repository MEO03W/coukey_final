//
//  SearchBAr.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 05.07.23.
//

import SwiftUI

struct SearchBArView: View {
    let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
    @State private var searchText = ""
    
    var body: some View {
        VStack {
            HStack {
                TextField("Suchen", text: $searchText)
                    .foregroundColor(.black)
                    .padding(3)
                    .background(Color.white.opacity(0.15))
                    .multilineTextAlignment(.center)
                   
                    .cornerRadius(20)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(colorLax, lineWidth: 2)
                            //.background(Color.white)
                            //.opacity(0.8)
                            .cornerRadius(20)
                    )


                Spacer()
            }
           // .frame(width: 400, height: 400)
           // .background(Color.black)
            .padding()
            Spacer()
        }
        //.background(Color.clear)
    }
}


struct SearchBarView_Previews: PreviewProvider {
    static var previews: some View {
        SearchBArView()
    }
}
