//
//  ProfileView.swift
//  coukey_v01
//
//  Created by Student on 08.06.23.
//
//  prototype profile with account verify
import SwiftUI

struct ProfileView: View {
    
    @StateObject var viewModel = ProfileView_VM()
    @State var sheetIsUp : Bool = false
    var body: some View {
        
        VStack{
            Text("Verifiy my Phone Number now")
            Button("Verify") {
                viewModel.sendVerification()
                viewModel.codeSent = true
                //action
            }.buttonStyle(.borderedProminent)
        }
        .padding()
        .sheet(isPresented: $viewModel.codeSent) {
            //VerifyCodeSheetView()
            VStack {
               /* HStack{
                    
                    Text(viewModel.currentNumber)
                    
                    Image(systemName: viewModel.verified ?  "checkmark.circle.fill" : "circle")
                        .font(.system(size: 24))
                        .foregroundColor(viewModel.verified ? .green : .black)
                        .padding()
                        .frame(width: 30, height: 30)
                } */ 
                //TextField("Code",text:$viewModel.code)
                HStack{
                Spacer()
              
                    if viewModel.verified {
                        Text("You have been verified ")
                    }
                    
                    TextField("SMS CODE", text : $viewModel.confirmCode)
                    
                Spacer()
                }
                Button("Confirm"){
                    viewModel.confirmVerification()
                }
                    .buttonStyle(.borderedProminent)
                    
                    //.foregroundColor(.green)
                    .background(.green)
            }
        }
        
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
            
    }
}
