//
//  HomeView.swift
//  coukey_v01
//
//  Created by Student on 07.06.23.
//
//
import SwiftUI

struct HomeView: View {
    
    //@StateObject var viewModel = RecipeShort_VM()
    @StateObject var viewModel = ComplexRecipe_VM()
    @State private var currentAmount = 0.0
    @State private var finalAmount = 1.0
    @State private var currentView = "scrollView"
    //MARK: view
    

    var body: some View {
        if (viewModel.state == .loading) {
            VStack(alignment:.center){
                ProgressView()
            }
        }
        else {
        let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
        NavigationView{
        //ScrollViewReader{ scrollViewProxy in }
        ScrollView {
            LazyVStack(spacing: 10) {
                //render all list items
                ForEach(viewModel.reciperesponse?.results ?? [] ,id: \.id) { result in
                    ZStack(alignment: .bottomLeading) {
                       // URLImageView(urlString: result.image, data: nil)
                        
                        NavigationLink(destination: CoukingView(currentRecipe: result)){
                            URLImageView(urlString: "https://spoonacular.com/recipeImages/"+String(result.id)+"-556x370.jpg" , data: nil)
                            
                            .aspectRatio(contentMode: .fill)
                            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - 90)
                            .overlay(Rectangle()
                                        .foregroundStyle(LinearGradient(colors:[.clear, colorLax], startPoint: UnitPoint(x: 0.5, y: 0.5), endPoint: .bottom))
                            )
                            .clipped()
                            
                        }
     
                        Spacer()


                        ReceptPopUp(recipe : result)
                      
                    }
                }
                //renders a progression spinner
                //fetches more data on appear 
                ProgressView()
                    .onAppear{
                        
                        viewModel.fetchRecipeInfos(offSet: viewModel.reciperesponse?.results.count ?? 10)
                        //fetch more recipees
                    }
            }
        }
        
        .onAppear{
            //TODO: do this fetching once when the viewModel got init. .
            //viewModel.fetchComplexSearch()
            //info_viewModel.fetchRecipeInfos()
        }
        .edgesIgnoringSafeArea(.all)
        .navigationBarHidden(true)
            .navigationBarTitleDisplayMode(.inline)    }.accentColor(Color("Lax"))

  }
}
   
    

}


struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
