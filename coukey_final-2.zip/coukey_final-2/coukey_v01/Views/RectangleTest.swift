//
//  RectangleTest.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 29.06.23.
//

import SwiftUI
let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
struct RectangleTest: View {
    var body: some View {
        Rectangle()
        .foregroundColor(.clear)
        .frame(width: 161, height: 89)
        .background(colorLax)
    }
}

struct RectangleTest_Previews: PreviewProvider {
    static var previews: some View {
        RectangleTest()
    }
}
