//
//  testScrolling.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 21.06.23.
//
//
import SwiftUI

struct testScrolling: View {
    let images: [String] = ["image1", "image2", "image3", "image4","image4","image4","image4","image4","image4",]
    var body: some View {
       
       

            
                ScrollViewReader { scrollViewProxy in
                    ScrollView {
                        LazyVStack(spacing: 0) {
                            ForEach(images, id: \.self) { imageName in
                                GeometryReader { geometry in
                                    Image(imageName)
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(height: UIScreen.main.bounds.height)
                                        .offset(y: -geometry.frame(in: .global).minY)
                                       // .animation(.easeInOut)
                                        .onAppear {
                                            scrollViewProxy.scrollTo(imageName, anchor: .top)
                                        }
                                }
                                .frame(height: UIScreen.main.bounds.height)
                            }
                        }
                    }
                }
            }
        
    
}


struct testScrolling_Previews: PreviewProvider {
    static var previews: some View {
        testScrolling()
    }
}
