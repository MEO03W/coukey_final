//
//  Profile_View.swift
//  coukey_v01
//
//  Created by Lucas Hoge on 02.07.23.
//

import SwiftUI

struct Profile_View: View {
    
    //Authentification viewmodel import
    @EnvironmentObject var auth_vm : Authentification_VM
    
    //Get showUser state from components binding
    @State var showUser: Bool = true
    
    //Get indicator state from components binding
    @State var imgState: Bool = false
    
    @State var showAlert: Bool = false
    
    @State var isDisabled:Bool = true
    var body: some View {
        
        //Navigation View Wrapper to place Nav Items at the top screen
        NavigationView{
            ZStack(alignment: .top) {
                
                //Gradient Background
                    Image("ProfileGradientLong")
                        .resizable()
                
                        //imgState animation call toggle from
                        //toggle from tab buttons in profile banner
                        .offset(x: imgState ? 190 : -190)
                        .blur(radius: 23)
                        .aspectRatio(contentMode: .fill)
                        .frame(width: UIScreen.main.bounds.width , height: 357 )
                        .clipped()
                        
                VStack{
                    
                    //Appliance of state bindings from ProfiileBanner
                    ProfileBanner(showUser: $showUser, imgState: $imgState)
                    if showUser {
                        UserList(isDisabled: $isDisabled)
                    } else {
                        Favorites()
                    }
                }
            }
            .navigationBarHidden(false)
            .navigationBarTitleDisplayMode(.inline)
            
            //Toolbar insertion for top navigation
            .toolbar{
                //View name text titel
                ToolbarItem(placement: .principal) {
                    VStack {
                        Text("Profile")
                            .foregroundColor(Color("Lax"))
                    }
                }
                //Edit button insertion
                ToolbarItem(placement: .navigationBarLeading){
                    Button{
                        isDisabled = !isDisabled
                    } label: {
                        Text("Edit").foregroundColor(Color("Lax"))
                        
                    }
                    
                }
                //Logout button insertion
                ToolbarItem(placement: .navigationBarTrailing){
                    Button{
                        showAlert = true
                    }label: {
                        Image(systemName: "rectangle.portrait.and.arrow.right")
                            .foregroundColor(Color("Lax"))
                            .font(.system(size: 14))
                    }.alert("Logout", isPresented: $showAlert){
                        Button("Just on this device", role: .destructive){auth_vm.logout()}
                        Button("On all Devices", role: .destructive){auth_vm.logout_all()}
                        Button("CANCEL", role: .cancel){}
                        
                    }
                    
                }
            }
        }
    }
}

struct Profile_View_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            Profile_View()
        }
    }
}
