//
//  RegisterView.swift
//  coukey_v01
//
//  Created by Student on 18.05.23.
//
//
import SwiftUI

struct RegisterView: View {
    
    //viewmodel bind
    @EnvironmentObject var viewModel : Authentification_VM
    
    //single animation attribute
    @State var opacity = 0.0

    
    //lets us register a new user 
    var body: some View {
        VStack{
            ZStack{
                Color.white
                    .ignoresSafeArea()
                Image("TextFrame")
                    .resizable()
                    .frame(width: 251, height: 187)
                    

                VStack(alignment: .leading, spacing: -6){
                    Text("COUKEY")
                        .foregroundColor(Color("DarkLax"))
                        .font(.system(size:42, weight: (.bold)))
                    Text("Join")
                        .foregroundColor(Color("Lax"))
                        .font(.system(size:42, weight: (.regular)))
                        .multilineTextAlignment(.leading)
                        .lineLimit(0)
                        .padding(0.0)
                        .opacity(opacity)
                    Text("Now!")
                        .foregroundColor(Color("Lax"))
                        .font(.system(size:42, weight: (.regular)))
                        .multilineTextAlignment(.leading)
                        .lineLimit(0)
                        .padding(0.0)
                        .opacity(opacity)
                        //one global animation call for "opacity" with according delay on appear
                        .onAppear{
                            withAnimation(.easeIn(duration: 0.1)){
                                self.opacity = 1.0
                                
                            }
                        }
                }
                .padding(0.0)
                .offset(x: -20, y: -18)
                
                
                Image("CoukyLogo")
                    .resizable()
                    .frame(width: 111, height: 111)
                    .offset(x: 52, y: 21)
                    
            }
            Form{
                if !viewModel.errorMsg.isEmpty{
                    Text(viewModel.errorMsg)
                }
                TextField("Name", text:$viewModel.name).padding(.leading, 10)
                    .RoundedTextfieldStyle02()
                    .listRowSeparator(.hidden)
                TextField("Email", text:$viewModel.email).padding(.leading, 10)
                    .RoundedTextfieldStyle02()
                    .listRowSeparator(.hidden)
                    .autocapitalization(.none)
                SecureField("Eassword", text:$viewModel.password).padding(.leading, 10)
                    .RoundedTextfieldStyle02()
                    .listRowSeparator(.hidden)
                
                Button {
                    viewModel.register()
                    
                } label : {
                    ZStack{
                        Rectangle()
                            .foregroundColor(Color("Purple"))
                            .cornerRadius(25)
                        Text("Register")
                            .foregroundColor(Color.white)
                            .font(.system(size:19, weight: (.bold)))
                    }
              
                    
                }
                
            }
        }
        
        
        
    }
}

struct RegisterView_Previews: PreviewProvider {
    static var previews: some View {
        RegisterView()
    }
}
