//
//  SearchAndGridView.swift
//  coukey_v01
//
//  Created by Student on 08.06.23.
//
//
// 
import SwiftUI

struct SearchAndGridView: View {
    @State private var searchText = ""

    var body: some View {
        ZStack {
           SearchAndGridContentView()
                //.padding(.top, 70)
                
                .overlay(
                    SearchBArView()
                        .padding(.top,100)
                      //  .opacity(0.5)
                )
            VStack {
                Spacer()
                // Rest des Inhalts hier
            }
        }.ignoresSafeArea()
    }


}


struct SearchAndGridView_Previews: PreviewProvider {
    static var previews: some View {
        SearchAndGridView()
    }
}
