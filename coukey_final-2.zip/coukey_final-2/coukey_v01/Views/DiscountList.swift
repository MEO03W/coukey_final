//
//  DiscountList.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 23.06.23.
//

import SwiftUI

struct DiscountList: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct DiscountList_Previews: PreviewProvider {
    static var previews: some View {
        DiscountList()
    }
}
