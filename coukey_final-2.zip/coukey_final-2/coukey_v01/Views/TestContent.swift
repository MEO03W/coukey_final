
//
import SwiftUI

struct TestContent: View {
    let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
    let images: [String] = ["image1", "image2", "image3", "image4"]
    @State var heartChecked : Bool =  false
    
    var body: some View {
        ScrollView {
            LazyVStack(spacing: 10) {
                ForEach(images, id: \.self) { imageName in
                    ZStack(alignment: .bottomLeading) {
                        Image(imageName)

                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - 90)
                            .overlay(Rectangle()
                                .foregroundStyle(LinearGradient(colors:[.clear, colorLax], startPoint: UnitPoint(x: 0.5, y: 0.5), endPoint: .bottom))
                            )
                        HStack{
                            ReceptPopUp(recipe: nil)
                            Button{
                                
                                //check for fave
                                //if not in list add it and then heartchecked = true
                                //if in list then delete it and uncheck heart
                                heartChecked = !heartChecked
                                
                            } label: {
                                
                                Image(systemName: heartChecked ? "heart" : "heart.fill")
                                    .foregroundColor(Color.white)
                                    .font(.system(size: 24))
                            }
                            
                        }
                        
                    }
                }
            }
        }
        .edgesIgnoringSafeArea(.all)
    }
}

struct TestContent_Previews: PreviewProvider {
    static var previews: some View {
        ZStack {
            TestContent()
            
            VStack {
                Spacer()
            }
        }
    }
}
