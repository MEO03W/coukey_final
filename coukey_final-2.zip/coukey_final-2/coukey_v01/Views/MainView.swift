//
//  ContentView.swift
//  coukey_v01
//
//  Created by Student on 18.05.23.
//
//
import SwiftUI
/**
this thing handles if we are logged in when starting the app, if yes then it goes to the home view if not we go to login view
Main View is Parent View of all
*/

struct MainView: View {
    @State private var showIntro: Bool = true
    @EnvironmentObject var auth_vm : Authentification_VM
    var body: some View {
        ZStack{

            VStack{
                if auth_vm.isLoggedIn , !auth_vm.currentUserId.isEmpty {
                    AppStart1()

                } else {
                    LoginView()
                }
            }
            
        }
        
    }
 
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
