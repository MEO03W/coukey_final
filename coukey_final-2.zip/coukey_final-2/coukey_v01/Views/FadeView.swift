//
//  FadeView.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 29.06.23.
//
//
import SwiftUI

struct FadeView: View {
    var body: some View {
        Text("hello")
    }
}

struct FadeView_Previews: PreviewProvider {
    static var previews: some View {
        FadeView()
    }
}
