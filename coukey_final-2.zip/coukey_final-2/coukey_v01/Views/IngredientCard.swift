//
//  IngredientCard.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 29.06.23.
//

import SwiftUI

struct IngredientCard: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct IngredientCard_Previews: PreviewProvider {
    static var previews: some View {
        IngredientCard()
    }
}
