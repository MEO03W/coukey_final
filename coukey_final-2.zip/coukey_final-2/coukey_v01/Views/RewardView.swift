//
//  RewardView.swift
//  coukey_v01
//
//  Created by Student on 08.06.23.
//
//
import SwiftUI
/*
 struct RewardView: View {
 var body: some View {
 
 
 ScrollView {
 RewardBanner()
 VStack {
 //RewardBanner()
 //padding(0)
 ForEach(0..<10) { durchlauf in
 SponsorContainer()
 }
 }
 }
 }
 
 }
 */

struct RewardView: View {
    let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
    @State private var showRewards = true
    @State var imgState: Bool = false
    var body: some View {
        
        NavigationView{
            ZStack(alignment: .top) {
                //Gradient Background
                    Image("ProfileGradientLong")
                        .resizable()
                        .offset(x: imgState ? 190 : -190)
                        .blur(radius: 23)
                        .aspectRatio(contentMode: .fill)
                        .frame(width: UIScreen.main.bounds.width , height: 357 )
                        .clipped()
                VStack{
                    RewardBanner(showRewards: $showRewards, imgState: $imgState)
                    if showRewards {
                        RewardList()
                    } else {
                        //How to view here
                        Spacer()
                    }
                    


                }
            }
            
            .navigationBarHidden(false)
            .navigationBarTitleDisplayMode(.inline)
            
            .toolbar { // <2>
                        ToolbarItem(placement: .principal) { // <3>
                            VStack {
                                Text("Yumm Rewards")
                                    .foregroundColor(Color("Lax"))
                            }
                        }
                    }
            
        }
            

        
    }
}


struct RewardView_Previews: PreviewProvider {
    static var previews: some View {
        RewardView()
    }
}
