//
//  CoukingView.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 28.06.23.
//
//
import SwiftUI



struct CoukingView: View {
    
    let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
    @State private var showCard = true
    @State private var isStepsSelected = false
    //@State  var kcl: Int?
    let currentRecipe : Result?
    @State var count: Int = 0
    
    init(currentRecipe : Result?){
        self.currentRecipe = currentRecipe
        self._count = State(initialValue: currentRecipe?.servings ?? 1)
    }
    
    //TODO: change kcal to healtscore, healthscore : int (0-100)
    //
    var body: some View {
        VStack{
            CoukingBannerView(currentRecipe: currentRecipe,  showCard: $showCard, isStepsViewSelected: $isStepsSelected, servingsCount : $count)
        if showCard {
            VStack{
                CardList(allIngredients:currentRecipe?.extendedIngredients ?? [], originalServingsCount: self.currentRecipe?.servings ?? 1, servingsCount: $count)
                
                Spacer()
                    .overlay(
                        Rectangle()
                            .foregroundStyle(LinearGradient(colors:[.clear, .white], startPoint: UnitPoint(x: 0.5, y: 0.5), endPoint: .bottom))
                            .frame(width: 300, height: 100, alignment: .bottom)
                                            
                    )//.alignmentGuide(.center)
            }
        } else {
            HowToView(instructions : currentRecipe?.analyzedInstructions ?? [])
            //RewardList()
        }
        
        }
          //.navigationBarBackButtonHidden(false)
          .navigationBarHidden(false)
    }
    
}

struct CoukingView_Previews: PreviewProvider {
    static var previews: some View {
        CoukingView(currentRecipe: nil)
    }
}



