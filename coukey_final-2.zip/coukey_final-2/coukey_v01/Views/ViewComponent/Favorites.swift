//
//  Favorites.swift
//  coukey_v01
//
//  Created by Lucas Hoge on 03.07.23.
//

import SwiftUI

struct Favorites: View {
    var body: some View {
        //Favorites View dummy spacer
        Spacer()
        
    }
}

struct Favorites_Previews: PreviewProvider {
    static var previews: some View {
        Favorites()
    }
}
