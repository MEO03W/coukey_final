//
//  RewardBanner.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 21.06.23.
//
//
import SwiftUI

struct RewardBanner: View {
    //Animation & page bindings
    @Binding var showRewards: Bool
    
    //Indicator for Tab Indicator Bar
    @State var indicator: Bool = false
    
    //Background gradient Animation binding
    //Background sits in the Profile_View
    @Binding var imgState: Bool
    
    var body: some View {
        ZStack(alignment: .bottom) {
            VStack(alignment: .center, spacing: 0) {
                HStack{
                    Rectangle()
                        .foregroundColor(.white)
                        .frame(width: 280, height: 166)
                        .cornerRadius(25)
                        .overlay(
                            VStack {
                                Text("Hello Liam Meyer;)")
                                    .foregroundColor(.black)
                                    .font(Font.headline)
                                
                                Text("Your Yum Points:)")
                                    .foregroundColor(.black)
                                    .font(Font.subheadline)
                                
                                Text("78")
                                    .foregroundColor(.black)
                                    .font(Font.headline)
                                    .font(.system(size: 42))
                                    .padding(25)
                            }
                        )
                }.padding(.top, 22)
                Spacer()
                
                HStack {
                    Button(action: {
                        showRewards = true // Setzen Sie den Binding-Wert auf true, um den View unten zu ändern
                        
                        //Page Switch indicator and background animatino toggle
                        withAnimation(.easeInOut(duration: 0.3)){
                                    indicator = false
                                    imgState = true
                                }
                    }) {
                        ZStack {
                            Rectangle()
                                .foregroundColor(showRewards ? Color("Purple") : Color("Purple").opacity(0.5))
                                .cornerRadius(25)
                                .frame(width: 122, height: 32)
                            
                            Text("Rewards")
                                .foregroundColor(Color.white)
                                .font(.system(size:19, weight: (.bold)))
                        }
                    }

                    Button(action: {
                        showRewards = false // Setzen Sie den Binding-Wert auf false, um den View unten zu ändern
                        
                        //Page Switch indicator and background animatino toggle
                        withAnimation(.easeInOut(duration: 0.3)){
                                    indicator = true
                                    imgState = false
                                }
                    }) {
                        ZStack {
                            Rectangle()
                                .foregroundColor(showRewards ? Color("Purple").opacity(0.5) : Color("Purple"))
                                .cornerRadius(25)
                                .frame(width: 122, height: 32)
                            
                            Text("How to?")
                                .foregroundColor(Color.white)
                                .font(.system(size:19, weight: (.bold)))
                        }
                    }
                }
                .padding(.bottom, 15.0)
            }.padding(0.0).frame(height: 242.0)
            ZStack {
                //Outer Bar
                RoundedRectangle(cornerRadius: 30)
                    .foregroundColor(Color("LightLax"))
                    .frame(width: 129, height: 12)
                //Innter Bar
                RoundedRectangle(cornerRadius: 30)
                    .foregroundColor(.gray)
                    .frame(width: 60, height: 4)
                    .offset(x: !indicator ? -27 : 27)
            }.offset(y:7)
        }
    }
}

struct RewardBanner_Previews: PreviewProvider {
    @State private var showRewards = false
    
    static var previews: some View {
        RewardBanner(showRewards: .constant(false), imgState: .constant(false))
    }
}
