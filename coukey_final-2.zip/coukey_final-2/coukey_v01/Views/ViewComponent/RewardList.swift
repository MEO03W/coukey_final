//
//  RewardList.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 23.06.23.
//
//
import SwiftUI

struct RewardList: View {
    //Dummy images reward String to feed the reward cards with images
    let images: [String] = ["REWE", "Denns Bio Markt", "ALECO", "Bio Markt", "Denns Bio Markt", "REWE", "ALECO", "Bio Markt"]
    //Dummy actionText reward String to feed the reward cards
    let actionText: [String] = ["1kg aplles on for free on your next purchase", "20% off on all fresh produce such as fruits, vegetables, and meat.", "Buy one, get one free offer: Purchase one pack of pasta and get a second pack for free.", "50% off on all household cleaners and cleaning supplies.", "Free gift with a minimum purchase of 20 euros in the confectionery department."]
//    let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
    
    var body: some View {
        
            VStack{
                
                //Scroll View for RewardList items
                ScrollView(showsIndicators: false){
                    
                    VStack {
                        
                        ForEach(images.indices, id: \.self) { index in
                            NavigationLink(destination: QRView()) {
                                SponsorContainer(actionText: actionText.randomElement() ?? "", imageName: images[index], sponsorName: images[index], points: Int.random(in: 25...120))
                            }.foregroundColor(.black)
                        }
                    }
                }
                
            }
            .padding(.top, 30.0)
            

    }
    
}

struct RewardList_Previews: PreviewProvider {
    static var previews: some View {
        RewardList()
    }
}
