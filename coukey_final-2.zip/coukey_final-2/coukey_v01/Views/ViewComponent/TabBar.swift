//
//  TabBar.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 14.06.23.
//
//


import SwiftUI



struct TabBar: View {
    
    let colorOrange = Color(red: 0.89020, green: 0.70980, blue: 0.01961)
    let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
    
    @Binding var selectedTab:Tab
    
    private var fillImage: String{
        selectedTab.rawValue + ".fill"
    }
    
    var body: some View {
        
        VStack{
            HStack{
                // Packt ein Icon in die Bar und packt dann einen Spacer rein
                ForEach(Tab.allCases,id: \.rawValue){ tab in
                    Spacer()
                    Image(systemName: selectedTab == tab ? fillImage : tab.rawValue)
                        .scaleEffect(tab == selectedTab ? 1.25 : 1.0)
                        .foregroundColor(selectedTab == tab ? colorLax : .black)
                        .font(.system(size: 25))
                        .onTapGesture {
                            withAnimation(.easeIn(duration: 0.1)){
                                selectedTab = tab
                            }
                        
                    }
                  
                    Spacer()
                }
                
                
            }
        }
        .frame(width: nil, height: 90)
        //zum Switchen der light and dark Modis =>.thinMaterial
        .background(.white)
        .cornerRadius(0)
        .padding(0)
        
    }
}
//Ein Aufzählungstyp(Enum) (englisch enumerated type) ist ein Datentyp für Variablen mit einer endlichen Wertemenge. Alle zulässigen Werte des Aufzählungstyps werden bei der Deklaration des Datentyps mit einem eindeutigen Namen

// String als Datentyp und CaserIterable um einen Loop hindurch zu machen

// Tab funtktion um zu gucken auf welchen Reiter wir geclickt haben
enum Tab: String, CaseIterable{
    // Stamment aus SF Symbols
    case dollarsign  = "dollarsign.circle"
    case house  = "house.circle"
    case cart = "plus.circle"
    case magnifyingglass = "magnifyingglass.circle"
    case person = "person.circle"

    
}





struct TabBar_Previews: PreviewProvider {
    static var previews: some View {
        
        TabBar(selectedTab:.constant(.house))
        
    }
}
