//
//  QRView.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 21.06.23.
//
//
import SwiftUI

struct QRView: View {
    //Dummy QR-Code for the RewardList cards
    var body: some View {
        Image("QR-Code")
            .resizable()
            .frame(width: 200, height: 200)
    }
}

struct QRView_Previews: PreviewProvider {
    static var previews: some View {
        QRView()
    }
}
