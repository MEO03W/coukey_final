//
//  UIImageView.swift
//  coukey_v01
//
//  Created by Student on 12.06.23.
//
//
import SwiftUI

struct URLImageView: View {
    
    let urlString:String
    @State var data : Data?
    
    var body: some View {
        let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
        
        if let data = data, let uiimage = UIImage(data: data) {
            Image(uiImage: uiimage)
                .resizable()
                //.aspectRatio(contentMode: .fill)
                //.clipped()
                //.frame(width: nil, height: UIScreen.main.bounds.height / 2 )
                //.aspectRatio(contentMode: .fit)
        }
        else {
            
            /*Image(systemName: "video")
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height / 2 )
                .background(Color.orange)*/
            
            ZStack{
                Rectangle().frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
                ProgressView()
                 }
                .overlay(Rectangle()
                        .foregroundStyle(LinearGradient(colors:[.clear, colorLax], startPoint: UnitPoint(x: 0.5, y: 0.5), endPoint: .bottom))
                )
                .onAppear{
                    fetchImageData()
                }
        }
        
        
    }
    private func fetchImageData(){
        guard let url = URL(string: urlString) else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url ) {data, _ , _ in
            self.data = data
        }
        task.resume()
    }
}

struct URLImageView_Previews: PreviewProvider {
    static var previews: some View {
        URLImageView(urlString: "https://spoonacular.com/recipeImages/716426-312x231.jpg", data: nil)
    }
}
