//
//  CoukingBannerView.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 29.06.23.
//
//
import SwiftUI

struct CoukingBannerView: View {
    let currentRecipe : Result?
    @Binding var showCard: Bool
    
    //Count Binding to RecipeCounter
    @Binding var count : Int
    
    //Macro ingredient state for the steps tab
    @State var kcl: Int?
    
    //Indicator for Tab Indicator Bar
    @State var indicator: Bool = false

    //Binding to change content Box nav
    //Cart = Servings count / RecipeCounterView toggle
    //Steps = Healthscore and macros / CoukingStepsStatsView
    @Binding var isStepsViewSelected: Bool
    
    let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
    let colorYellow = Color(red: 0.89, green: 0.71, blue: 0.02)
    
    //Binding init to pass states
    init(currentRecipe : Result?, showCard: Binding<Bool>, isStepsViewSelected : Binding<Bool>, servingsCount : Binding<Int>){
        self.currentRecipe = currentRecipe
        self._count = servingsCount
        self.kcl = currentRecipe?.healthScore ?? 1
        _showCard = showCard
        _isStepsViewSelected = isStepsViewSelected
    }
    
    var body: some View {
        ZStack(alignment: .bottom) {
            //Recipe Image from Spoonacular fetch
            //"rice.png" as start url on nil
            URLImageView(urlString: currentRecipe?.image ?? "https://www.spoonacular/rice.png", data: nil)
                
                .frame(width: 346, height: 243)
                .blur(radius: 3)
                .clipped()
                .overlay(
                    Rectangle()
                                .foregroundStyle(LinearGradient(colors:[.clear, colorLax], startPoint: UnitPoint(x: 0.5, y: 0.5), endPoint: .top))
                    
                )
            VStack(alignment: .center, spacing: 0){
                
                    
                      
                    
                    VStack {
                        Text(currentRecipe?.title ?? "Pomees")
                            .foregroundColor(.white)
                            .font(.system(size: 18))
                            .multilineTextAlignment(.center)
                        
                        //Spoonacular recipe scores fetch
                        if isStepsViewSelected {
                            CoukingStepsStatsView(stepAmount: currentRecipe?.analyzedInstructions.first?.steps.count, servingTime: currentRecipe?.readyInMinutes, healthScore: currentRecipe?.healthScore)
                        } else {
                            RecipCounterView(count: self.$count)
                        }
                    }.padding(.top, 50)
                Spacer()
                    
                    HStack {
                        Button(action: {
                            //Toggle to change content style of the corresponding buttons
                            showCard = true
                            isStepsViewSelected = false
                            
                            //Page Switch indicator and background animatino toggle
                            withAnimation(.easeInOut(duration: 0.3)){
                                        indicator = false
                                    }
                        }) {
                            ZStack {
                                Rectangle()
                                    .foregroundColor(showCard ? Color("Purple") : Color("Purple").opacity(0.5))
                                    .cornerRadius(25)
                                    .frame(width: 122, height: 32)
                                
                                Text("Cart")
                                    .foregroundColor(Color.white)
                                    .font(.system(size:19, weight: (.bold)))
                            }
                        }

                        Button(action: {
                            //Toggle to change content style of the corresponding buttons
                            showCard = false
                            isStepsViewSelected = true
                            
                            //Page Switch indicator and background animatino toggle
                            withAnimation(.easeInOut(duration: 0.3)){
                                        indicator = true
                                    }
                        }) {
                            ZStack {
                                Rectangle()
                                    .foregroundColor(showCard ? Color("Purple").opacity(0.5) : Color("Purple"))
                                    .cornerRadius(25)
                                    .frame(width: 122, height: 32)
                                
                                Text("Steps")
                                    .foregroundColor(Color.white)
                                    .font(.system(size:19, weight: (.bold)))
                            }
                        }
                    }
                    .padding(.bottom, 15.0)
                
            }.frame(width: 346, height: 242)
            //Tab Indicator Bar
            ZStack {
                //Outter Bar
                RoundedRectangle(cornerRadius: 30)
                    .foregroundColor(Color("LightLax"))
                    .frame(width: 129, height: 12)
                //Inner Bar
                RoundedRectangle(cornerRadius: 30)
                    .foregroundColor(.gray)
                    .frame(width: 60, height: 4)
                    .offset(x: !indicator ? -27 : 27)
            }.offset(y:7)
           
        }
        
        
    }
}

struct CoukingBannerView_Previews: PreviewProvider {
    static var previews: some View {
        CoukingBannerView(currentRecipe: nil, showCard: .constant(false), isStepsViewSelected: .constant(false) , servingsCount: .constant(1))
    }
}
