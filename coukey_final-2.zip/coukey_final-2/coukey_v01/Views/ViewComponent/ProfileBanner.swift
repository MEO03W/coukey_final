//
//  ProfileBanner.swift
//  coukey_v01
//
//  Created by Lucas Hoge on 01.07.23.
//

import SwiftUI

struct ProfileBanner: View {
    //Authentification viewmodel import
    @EnvironmentObject var auth_vm : Authentification_VM
    
    //Indicator for Tab Indicator Bar
    @State var indicator: Bool = false
    
    //Animation & page binding
    @Binding var showUser: Bool
    
    //Background gradient Animation binding
    //Background sits in the Profile_View
    @Binding var imgState: Bool
    
    
    var body: some View {
            
        ZStack(alignment: .bottom){
            VStack(alignment: .center, spacing: 0) {
                HStack {
                    Circle()
                        .fill(
                            LinearGradient(colors: [Color(red: 0.54, green: 0.9, blue: 0.78), Color(red: 0.6, green: 0.51, blue: 0.79)],
                                           startPoint: .top,
                                           endPoint: .trailing)
                        )
                        .frame(width: 148, height: 148)
                        //User Name by first Letter of User Name
                        .overlay(
                            Text(auth_vm.currentUserName.prefix(1))
                                .foregroundColor(.white)
                                .font(.system(size:80, weight: (.heavy)))
                           /* Image(systemName: "checkmark.circle.fill")*/
                        )
                        
                }.padding(.top, 22)
                Spacer()
                    
                //Button Row User/Faces
                HStack {
                    Button(action: {
                        //Toggle to change content style of the corresponding buttons
                        showUser = true
                        
                        //Page Switch indicator and background animatino toggle
                        withAnimation(.easeInOut(duration: 0.3)){
                                    indicator = false
                                    imgState = true
                                }
                    }) {
                        ZStack {
                            Rectangle()
                                .foregroundColor(showUser ? Color("Purple") : Color("Purple").opacity(0.5))
                                .cornerRadius(25)
                                .frame(width: 122, height: 32)
                            
                            Text("\(Image(systemName: "gearshape")) User")
                                .foregroundColor(Color.white)
                                .font(.system(size:19, weight: (.bold)))
                        }
                    }

                    Button(action: {
                        //Toggle to change content style of the corresponding buttons
                        showUser = false
                        
                        //Page Switch indicator and background animation toggle
                        withAnimation(.easeInOut(duration: 0.3)){
                                    indicator = true
                                    imgState = false
                                }
                    }) {
                        //Button Styling Stack
                        ZStack {
                            Rectangle()
                                .foregroundColor(showUser ? Color("Purple").opacity(0.5) : Color("Purple"))
                                .cornerRadius(25)
                                .frame(width: 122, height: 32)
                                                            
                            Text("\(Image(systemName: "heart")) Faves")
                            
                                .foregroundColor(Color.white)
                                .font(.system(size:19, weight: (.bold)))
                        }
                    }
                    
                }
                .padding(.bottom, 15.0)
                
            }.padding(0.0).frame(height: 242.0)
            
            //Tab Indicator Bar
            ZStack {
                //Outter Bar
                RoundedRectangle(cornerRadius: 30)
                    .foregroundColor(Color("LightLax"))
                    .frame(width: 129, height: 12)
                //Inner Bar
                RoundedRectangle(cornerRadius: 30)
                    .foregroundColor(.gray)
                    .frame(width: 60, height: 4)
                    .offset(x: !indicator ? -27 : 27)
            }.offset(y:7)
        }
            
        
            
            
       
        
        
    }
}

struct ProfileBanner_Previews: PreviewProvider {
    static var previews: some View {
        ProfileBanner(showUser: .constant(false), imgState: .constant(false))
    }
}
