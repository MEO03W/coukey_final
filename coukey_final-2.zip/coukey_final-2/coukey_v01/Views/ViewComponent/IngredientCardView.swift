//
//  IngredientCardView.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 29.06.23.
//
//
import SwiftUI

struct IngredientCardView: View {
    
    //Attributes to pass recipe data to the specific cards
    let ingredientName: String
    let unitName: String
    let amount: Double
    let imgUrl : String
    let onRemove: () -> Void
    
    
  
    
    var body: some View {
        ZStack(alignment: .trailing) {
            Rectangle()
                .foregroundColor(.clear)
                .frame(width: 161, height: 89)
                .background(Color("Lax"))
            
            HStack {
                Rectangle()
                    //Card Image
                    .foregroundColor(Color("LightLax"))
                    .frame(width: 73, height: 73)
                    .overlay(
                       URLImageView(urlString: "https://spoonacular.com/cdn/ingredients_100x100/\(imgUrl)", data: nil)
                            .frame(width: 54, height: 54)
                    )
                //Ingredient Image
                VStack(alignment: .leading) {
                    Text(ingredientName)
                        .foregroundColor(Color.white)
                        .font(.system(size: 16))
                        .padding(.top, 5)
                    //Ingredient amount insertion
                    HStack{
                        Text("\(String(format: "%.1f",amount)) \(unitName)")
                            .foregroundColor(Color.white)
                            .font(.system(size: 14))
                        
                        
                    }

                    
                    
                    Button(action: onRemove) {
                        Image(systemName: "trash.fill")
                            .foregroundColor(.black)
                            .alignmentGuide(.leading) { _ in
                                -60
                            }
                            .padding(.bottom, 5)
                    }
                }
            }
            .frame(width: 169, height: 89, alignment: .leading)
        }
    }
}


struct IngredientCardView_Previews: PreviewProvider {
    static var previews: some View {
        IngredientCardView(ingredientName: "Kartoffeln", unitName: "kg", amount: 0.23, imgUrl:" https://spoonacular.com/cdn/ingredients_100x100/apple.jpg" ){}
    }
}

