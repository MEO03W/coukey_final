//
//  ReceptPopUp.swift
//  TabBar
//
//  Created by Fynn Fenton on 07.06.23.
//
//
import SwiftUI
/**Recipe PopUp, contains all popup functionality, with name, time, tags, and so on */
struct ReceptPopUp: View {
    @State private var isPopUpVisible = false
    @State private var isButtonVisible = true
    let recipe : Result?
    @State private var heartChecked: Bool = false
    @EnvironmentObject var auth_vm : Authentification_VM
    
    init(recipe : Result?){
        self.recipe = recipe
    }
    
    func checkheart(){
        self.heartChecked = auth_vm.recipeIsFavorite(recipeId : recipe!.id)
    }
    
    var body: some View {
        let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
       
        ZStack {

            if isPopUpVisible {
                VStack {
                    HStack {
                        ZStack{

                        VStack {

                            
                            Button(action: {
                                isPopUpVisible.toggle()
                                isButtonVisible.toggle()
                            }) {
                                
                               Image(systemName: "arrow.down.square.fill")
                                    .font(.system(size: 35))
                                    .foregroundColor(.white)
                                    .frame(width: UIScreen.main.bounds.width , height: 50)
                                    .opacity(0.0)
                            }
                            
                            HStack{
                                Text(recipe!.title)
                                    .font(Font.custom("Inter", size: 18))
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(.white)
                                    .frame(width: 211)
                                
                                
                                Button {
                                    heartChecked ? auth_vm.deleteFavoriteFromTheList(recipeId: recipe!.id) : auth_vm.addNewFavorite(recipeId: recipe!.id)
                                    heartChecked = !heartChecked
                                } label: {
                                    Image(systemName: heartChecked ? "heart.fill" : "heart")
                                        .foregroundColor(Color.white)
                                        .font(.system(size: 24))
                                }
                            }
                          
                            Spacer()
                            HStack{
                                Spacer()
                                Text("\(Image(systemName: "clock")) \(recipe!.readyInMinutes) min")
                                    //TODO: make icon bold or bigger
                                    .font(Font.custom("Inter", size: 18))
                                    .foregroundColor(.white)
                                Spacer()
                                Text("\(Image(systemName: "circle"))10")
                                    .font(Font.custom("Inter", size: 18))
                                    .foregroundColor(.white)
                                Spacer()
                                
                            }
                            Spacer()
                            //TODO: make this more nice beautifulllll pls
                            HStack{
                                Spacer()
                                
                                TagView(tagName : recipe!.diets.last! , color: Color("TagGreen"))
                                    .padding(5)
                                
                                TagView(
                                    tagName : recipe!.cuisines?.first ?? recipe!.dishTypes.first ?? "",
                                    color: Color.white
                                        )
                                    .padding(5)
                                
                                TagView(tagName : recipe!.diets.first! , color: Color.white)
                                    .padding(5)
                                
                                Spacer()
                            }
                            .background(Color("Lax"))
                            
                            Spacer()
                        }
                            

                    }
                    }
                    
                    .frame(width: UIScreen.main.bounds.width, height: 250)
                    
                    .background(Color("Lax"))
                    .opacity(0.8)
                    .cornerRadius(0)
                    .padding(0)

                    
                    
                }
            }
            
            if isButtonVisible {
                VStack {
                    Button(action: {
                        withAnimation{
                            isPopUpVisible.toggle()
                            isButtonVisible.toggle()
                        }
                        
                    }) {
                        
                        HStack{
                            
                            VStack(alignment: .leading) {
                                Spacer()
                                HomeViewProfile(recipeName: recipe!.title)
                                    .padding(.bottom, 1)
                                Text("Click here to see more...")
                                    .font(.system(size: 15))
                                    .foregroundColor(.white)
                                
                                    /*.alignmentGuide(.leading) { _ in
                                        -35 // Hier kann man den Abstand anpassen
                                     
                                    }*/
                            }
                            Spacer()
                            
                            Button {
                                heartChecked ? auth_vm.deleteFavoriteFromTheList(recipeId: recipe!.id) : auth_vm.addNewFavorite(recipeId: recipe!.id)
                                heartChecked = !heartChecked
                            } label: {
                                Image(systemName: heartChecked ? "heart.fill" : "heart")
                                    .foregroundColor(Color.white)
                                    .font(.system(size: 24))
                            }
                                
                        }

                    }
                    .padding()
                    Spacer()
                }
            }
        }
        .onAppear(){
            checkheart()
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height / 4)
    }
       
}


struct ReceptPopUp_Previews: PreviewProvider {
    static var previews: some View {
        
        ReceptPopUp(
            recipe: nil
                /*Result(vegetarian: true, vegan: true, glutenFree: true, dairyFree: false, veryHealthy: false, cheap: false, veryPopular: false, sustainable: false, lowFodmap: true, weightWatcherSmartPoints: 10, preparationMinutes: 10, cookingMinutes: 10, aggregateLikes: 10, healthScore: 30, creditsText: "lecook", sourceName: "cookey.com", pricePerServing: 12.34, id: 92847, title: "nice avacado-lemon pasta", readyInMinutes: 25, servings: 2, sourceURL: "https://coukey.com", image: "", imageType: .jpg, summary: "coookokokooay", cuisines: ["pasta"], dishTypes: ["italian"], diets: ["gluten free","vegan"], occasions: [" "], extendedIngredients: [EdIngredient(id: 23412, image: "https://spoonacular.com/cdn/ingredients_100x100/apple", name: "apple", original: "apple_", amount: 5.0, unit: "pcs", meta: ["a-frutis"])], analyzedInstructions: [AnalyzedInstruction()], spoonacularSourceURL: "cdn//ads 87hajsdijfika", license: "cclclasllc")*/
        )
        
    }
}
