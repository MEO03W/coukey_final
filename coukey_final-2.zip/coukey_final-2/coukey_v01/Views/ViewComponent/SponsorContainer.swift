//
//  SponsorContainer.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 15.06.23.
//
//
import SwiftUI

struct SponsorContainer: View {
    let actionText: String
    let imageName: String
    let sponsorName: String
    let points: Int
    
    
    var body: some View {
        ZStack(alignment: .trailing){
            Rectangle()
                .foregroundColor(Color("Lax"))
                .frame(width: 338, height: 89)
            HStack {
             
                Rectangle()
                    .foregroundColor(Color("LightLax"))
                    .frame(width: 73, height: 73)
                
                
                    .overlay(
                        Image(imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 54, height: 54)
                        
                    )
                //(alignment: .leading)
                VStack(alignment: .leading){
                    Text(sponsorName)
                        .font(Font.headline)
                        .padding(.top,5)
                    
                    Spacer()
                    Text(actionText)
                        .font(Font.subheadline)
                        .lineLimit(1)
                        .padding(2)
                    
                    Spacer()
                    VStack{
                        
                        Text("points: \(points)")
                            .font(Font.headline)
                            .foregroundColor(.white)
                            .padding(2)
                            .frame( alignment: .trailing)
                        
                            .alignmentGuide(.leading) { _ in
                                -170 // Hier kann man den Abstand anpassen
                            }
                        
                    }
                }
                
                
                
                
                
            }
            .frame(width: 348, height: 89)
            
        }
        
        
    }
}

struct SponsorContainer_Previews: PreviewProvider {
    static var previews: some View {
        SponsorContainer(actionText: "1kg apples on your next purchase", imageName: "Denns_BioMarkt", sponsorName: "Denns Bio Markt", points: 60)
    }
}
