//
//  CardList.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 29.06.23.
//
//
import SwiftUI

struct CardList: View {
    
    private var gridItemLayout = [GridItem(.flexible(), spacing: -30), GridItem(.flexible(), spacing: 0)]
    @State var ingredients : [EdIngredient]
    private var originalServingsCount : Int
    @Binding var count : Int
    /*var ingredientName: String?
    @State private var ingredients: [EdIngredient]?
    */
    init(allIngredients : [EdIngredient] , originalServingsCount : Int, servingsCount : Binding<Int>){
        self.ingredients = allIngredients
        self.originalServingsCount = originalServingsCount
        self._count = servingsCount
    }
    //Test ingredients
    /*init() {
        let firstIngredient = EdIngredient(id: 1234, aisle: "", image: "rsdfgsdfg", name: "Tomaten", nameClean: "", original: "argaerg", originalName: "Tolli", amount: 234, unit: "wefwef", meta: ["sef","sef"], measures: Measures(us: Metric(amount: 23, unitShort: "kg", unitLong: ""), metric: Metric(amount: 2, unitShort: "kg", unitLong: "Kilogramm")), unitLong: "toller", unitShort: "tolli", extendedName: "super")
        let secondIngredient = EdIngredient(id: 333, aisle: "", image: "Brokoli", name: "BROKOLI", nameClean: "", original: "argaerg", originalName: "Tolli", amount: 234, unit: "wefwef", meta: ["sef","sef"], measures: Measures(us: Metric(amount: 23, unitShort: "kg", unitLong: ""), metric: Metric(amount: 2, unitShort: "kg", unitLong: "Kilogramm")), unitLong: "toller", unitShort: "tolli", extendedName: "super")
        let thirdIngredient = EdIngredient(id: 3323, aisle: "", image: "Brokoli", name: "Spinat", nameClean: "", original: "argaerg", originalName: "Tolli", amount: 234, unit: "wefwef", meta: ["sef","sef"], measures: Measures(us: Metric(amount: 23, unitShort: "kg", unitLong: ""), metric: Metric(amount: 2, unitShort: "kg", unitLong: "Kilogramm")), unitLong: "toller", unitShort: "tolli", extendedName: "super")
        let fourthIngredient = EdIngredient(id: 33033, aisle: "", image: "Brokoli", name: "Blumenkohl", nameClean: "", original: "argaerg", originalName: "Tolli", amount: 234, unit: "wefwef", meta: ["sef","sef"], measures: Measures(us: Metric(amount: 23, unitShort: "kg", unitLong: ""), metric: Metric(amount: 2, unitShort: "kg", unitLong: "Kilogramm")), unitLong: "toller", unitShort: "tolli", extendedName: "super")
        let fifthIngredient = EdIngredient(id: 332233, aisle: "", image: "Brokoli", name: "Nudeln", nameClean: "", original: "argaerg", originalName: "Tolli", amount: 234, unit: "wefwef", meta: ["sef","sef"], measures: Measures(us: Metric(amount: 23, unitShort: "kg", unitLong: ""), metric: Metric(amount: 2, unitShort: "kg", unitLong: "Kilogramm")), unitLong: "toller", unitShort: "tolli", extendedName: "super")
    
        _ingredients = State(initialValue: [firstIngredient, secondIngredient, thirdIngredient,fourthIngredient,fifthIngredient])
    }*/
    
    var body: some View {

        ZStack {
            VStack {
                ScrollView {
                    LazyVGrid(columns: gridItemLayout) {
                        ForEach(ingredients, id: \.self) { ingredient in
                            VStack {
                                let amountVal = (ingredient.measures?.metric.amount ?? ingredient.amount) / Double(originalServingsCount) * Double(count)
                                IngredientCardView(
                                    ingredientName: ingredient.name,
                                    unitName: ingredient.measures?.metric.unitShort ?? ingredient.unitShort!,
                                    amount: amountVal,
                                    imgUrl : ingredient.image ?? "https://cdn-icons-png.flaticon.com/512/271/271542.png"
                                    ) {
                                    if let index = ingredients.firstIndex(where: { $0.self == ingredient.self }) {
                                        withAnimation(.easeInOut){
                                            ingredients.remove(at: index)}
                                        }
                                }

                            }
                        }
                    }
                }
            }
            Spacer()
            VStack{
                Spacer()
                ZStack (alignment: .bottom){
                    
                    Button{
                        var pushContent = ""
                        for(ingredient) in ingredients {
                            let amountVal = (ingredient.measures?.metric.amount ?? ingredient.amount) / Double(originalServingsCount) * Double(count)
                            pushContent += "\(ingredient.name) \(amountVal) \(ingredient.measures?.metric.unitShort ?? ingredient.unitShort!)\n"
                        }
                        let center = UNUserNotificationCenter.current()
                        
                        // create content
                        let content = UNMutableNotificationContent()
                        content.title = "Couking Cart"
                        content.body = pushContent
                        
                        // create trigger
                        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5.0, repeats: false)
                        
                        // create request
                        let request = UNNotificationRequest(identifier: "Identifier", content: content, trigger: trigger)
                        
                        
                        // add request to notification center
                        center.add(request) { error in
                            if let error = error {
                                print(error)
                            }
                        }
                        
                    } label:{
                        
                        ZStack{
                            Circle()
                                .frame(height: 80.0)
                                .foregroundColor(Color("Purple"))
                            Text("Push")
                                .foregroundColor(.white)
                            Image("CartPush")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 80.0)
                        }
                    }.padding(33)
                }
            }
        }.padding(.top, 30.0)

        
        .navigationBarHidden(true)

    }
}

struct CardList_Previews: PreviewProvider {
    static var previews: some View {
        CardList(allIngredients: [], originalServingsCount: 1, servingsCount: .constant(1))
    }
}
