//
//  UIImageView.swift
//  coukey_v01
//
//  Created by Student on 12.06.23.
//

import SwiftUI

struct RectangleURLImageView: View {
    
    let urlString:String
    @State var data : Data?
    
    var body: some View {
        if let data = data, let uiimage = UIImage(data: data) {
            Image(uiImage: uiimage)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .clipped()
                //.frame(width: nil, height: UIScreen.main.bounds.height / 2 )
                //.aspectRatio(contentMode: .fit)
        }
        else {
            Image(systemName: "video")
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height / 2 )
                .background(Color.orange)
                .onAppear{
                    fetchImageData()
                }
        }
        
        
    }
    private func fetchImageData(){
        guard let url = URL(string: urlString) else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url ) {data, _ , _ in
            self.data = data
        }
        task.resume()
    }
}

struct RectangleURLImageView_Previews: PreviewProvider {
    static var previews: some View {
        RectangleURLImageView(urlString: "https://spoonacular.com/recipeImages/716426-312x231.jpg", data: nil)
    }
}
