//
//  ScrollAndSnap.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 28.06.23.
//
//
import SwiftUI

struct ScrollAndSnap: View {
    enum ScrollDirection {
        case up
        case down
        case none
    }
    
    @State var scrollDirection: ScrollDirection = .none
    let images: [String] = ["image1", "image2", "image3", "image4", "image1", "image4", "image3", "image1", "image9"]
    let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
    @State var isPopUpVisible = false
    @State var isButtonVisible = true
    
    var body: some View {
        VStack {
            ScrollViewReader { reader in
                List {
                    
                    ForEach(images, id: \.self) { imageName in
                        ZStack(alignment: .bottomLeading) {
                            VStack {
                                Image(imageName)
                                    .resizable()
                                    .overlay(Rectangle()
                                        .foregroundStyle(LinearGradient(colors:[.clear, colorLax], startPoint: UnitPoint(x: 0.5, y: 0.5), endPoint: .bottom))
                                    )
                            }
                            
                            //.frame(height: UIScreen.main.bounds.height)
                            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - 90)
                            ReceptPopUp(recipe : nil)
                                .onTapGesture {
                                    self.isPopUpVisible = !self.isPopUpVisible
                                }
                                .zIndex(1)
                               
                        }
                        
                        //.clipShape(Rectangle())
                        .id(imageName)
                        .gesture(
                            //DragGesture()
                            DragGesture(minimumDistance: 0.0)
                                .onChanged({ dragValue in
                                    let isScrollDown = 0 > dragValue.translation.height
                                    self.scrollDirection = isScrollDown ? .down : .up
                                })
                                .onEnded { value in
                                    let velocity = CGSize(
                                        width: value.predictedEndLocation.x - value.location.x,
                                        height: value.predictedEndLocation.y - value.location.y
                                    )
                                    if abs(velocity.height) > 100 {
                                        withAnimation(.easeOut(duration: 0.5)) {
                                            let currentIndex = images.firstIndex(of: imageName)!
                                            let nextIndex = currentIndex + (scrollDirection == .down ? 1 : -1)
                                            let next = images[nextIndex]
                                            reader.scrollTo(next, anchor: .top)
                                        }
                                    }
                                }
                        )
                       
                        
                    }
                    
                    .listRowSeparator(.hidden)
                    .listRowBackground(Color.clear)
                    .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                   
                }
                .listStyle(.plain)
    
            }.edgesIgnoringSafeArea(.all)
            
        }
    }
}

struct SampleSnappingListView_Previews: PreviewProvider {
    static var previews: some View {
        //NavigationView {
        ScrollAndSnap()
            //.navigationTitle("Snapping list")
            //.navigationBarTitleDisplayMode(.inline)
        //}
    }
}
