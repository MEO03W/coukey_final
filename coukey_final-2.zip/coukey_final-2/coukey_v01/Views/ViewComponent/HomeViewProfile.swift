//
//  ContentProfile.swift
//  TabBar
//
//  Created by Fynn Fenton on 08.06.23.
//
//
import SwiftUI

struct HomeViewProfile: View {
        
    var recipeName: String
        var body: some View {
        ZStack{
            HStack{
            Image(systemName: "fork.knife.circle")
                .font(.system(size: 24))

                .foregroundColor(.white)
            
            Text(recipeName)
                .foregroundColor(.white)
                .font(Font.headline)
                
                
                Spacer()
            }
            
            .frame(width: 200, height: 24)
        }
    }
}

struct ContentProfile_Previews: PreviewProvider {
    static var previews: some View {

        HomeViewProfile(recipeName: "pizza mit geile Soße")

    }
}
