//
//  TagView.swift
//  coukey_v01
//
//  Created by Student on 10.07.23.
//
/**
 * This is the tag view which contains builds a tag whith a tagname and border color
 */
import SwiftUI

struct TagView: View {
    
    let tagName : String
    let color : Color
    var value : String = " "
    
    var body: some View {
        
        ZStack{
            Color.white.opacity(0.15)
                .clipShape(Capsule())
            
            Text(tagName)
                .foregroundColor(.white)
                .padding(.vertical,4)
                .padding(.horizontal)
                .font(Font.custom("Inter",size: 12))
                //.background(Color.white.opacity(0.15))
                .clipShape(Capsule())
        }
        .overlay(
            Capsule()
                .stroke(color,lineWidth: 2)
        )
        .frame(width: 80 ,height: 20)
        /*
        Capsule()
            .foregroundColor(Color.white)
            .opacity(0.15)
            .frame(height: 44)
            .overlay(
                Text("\(tagName)")
                    .lineLimit(1)
                    .padding(.vertical,6)
                    .padding(.horizontal)
                    .foregroundColor(Color.white)
            )
         */
        /*
        Text(tagName)
            .lineLimit(1)
            .foregroundColor(Color.white)
            .padding(.vertical,6)
            .padding(.horizontal)
            .background(Color.white.opacity(0.15))
            .background(
                    Capsule()
                        .stroke(color,lineWidth: 2)
                        
                        
            )
            //.background(Capsule().white.opacity(0.15))
            
         */
    }
}

struct TagView_Previews: PreviewProvider {
    static var previews: some View {
        TagView(tagName: "vegetarian", color: Color.green).background(Color.red)
    }
}
