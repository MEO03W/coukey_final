//
//  VerifySheetView.swift
//  coukey_v01
//
//  Created by Student on 12.07.23.
//

import SwiftUI

struct VerifySheetView: View {
    
    //Authentification viewmodel import
    @EnvironmentObject var viewModel : Authentification_VM
    var body: some View {
        
        VStack {
            HStack{
                //VM currentUserPhone call
                Text(viewModel.currentUserPhone)
                    .foregroundColor(Color("Lax"))
                Image(systemName: viewModel.verified ?  "checkmark.circle.fill" : "circle")
                    .font(.system(size: 24))
                    .foregroundColor(viewModel.verified ? .green : .black)
                    .padding()
                    .frame(width: 30, height: 30)
            }
            //TextField("Code",text:$viewModel.code)
            HStack{
            Spacer()
          
                if viewModel.verified {
                    Text("You have been verified ")
                }
                Text("Code")
                    .padding(.leading, 8)
                    .padding(7)
                    .foregroundColor(Color("Lax"))
                HStack{
                    TextField("Code", text: $viewModel.confirmCode).padding(.leading, 10).foregroundColor(.gray)
                        .keyboardType(.numberPad)
                }.RoundedTextfieldStyle02()
                /**
                * probably we should have an nice validation here ,
                * but no time anymore
                * .. . . 
                 */
            Spacer()
            }
            Button{
                viewModel.confirmVerification()
                } label: {
                
                ZStack{
                    Rectangle()
                        .listRowSeparator(.hidden)
                        .frame(height: 34.0)

                        
                        .foregroundColor(Color("LightLax"))
                        .cornerRadius(25)
                    Text("Verify Account")
                        .font(.system(size:19, weight: (.bold)))
                        .foregroundColor(Color.white)
                }
            }
                                
        }
        
        
    }
}

struct VerifySheetView_Previews: PreviewProvider {
    static var previews: some View {
        VerifySheetView()
    }
}
