//
//  HowToView.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 23.06.23.
//
//
import SwiftUI



struct HowToView: View {
    
    let instructions : [AnalyzedInstruction]
    
    /** step
     let number: Int
     let step: String
     let ingredients, equipment: [Ent]
     let length: Length?
     
     */
    
    var body: some View {
        
        ScrollView{
            VStack(alignment: .leading){
            
                ForEach(instructions[0].steps ,id: \.number){
                    step in
                    
                    Text("\(step.number)")
                        .font(
                            Font.custom("Inter", size: 18)
                              .weight(.medium)
                        )
                        .foregroundColor(Color(red: 0.93, green: 0.44, blue: 0.44))
                        .frame(width: 162, height: 22, alignment: .topLeading)
                        
                    
                    Text("\(step.step)")
                        .font(
                            Font.custom("Inter", size: 14)
                              .weight(.medium)
                        )
                        .foregroundColor(.black)
                        .frame(width: 348, height: 61, alignment: .topLeading)
                }
           
                
            }
        }.padding(.top, 30.0)
      
    }
}

struct HowToView_Previews: PreviewProvider {
    static var previews: some View {
        HowToView(instructions: [])
    }
}
