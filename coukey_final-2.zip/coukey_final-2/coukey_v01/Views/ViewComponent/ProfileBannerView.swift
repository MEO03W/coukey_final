//
//  ProfileBannerView.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 01.07.23.
//
//
import SwiftUI

struct ProfileBannerView: View {
    var body: some View {
        ZStack{
        /*Rectangle()
            .foregroundColor(.clear)
            .frame(width: 390, height: 243)
            .background(Color(red: 0.73, green: 0.97, blue: 0.92))
         */
        Image("Liquid-shapes")
            .resizable()
            .frame(width: 422, height: 263)
        Rectangle()
            .foregroundColor(.clear)
            .frame(width: 148, height: 148)
            .background(Color(red: 0.85, green: 0.85, blue: 0.85))
            .cornerRadius(148)
        Rectangle()
            .foregroundColor(.clear)
            .frame(width: 422, height: 263)
            .background(
        Image("PATH_TO_IMAGE")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 422, height: 263)
                .clipped()
            )
            .blur(radius: 15)
     /*   HStack {
                Button(action: {
                   // showRewards = true
                }) {
                    ZStack {
                        Rectangle()
                            .foregroundColor(showRewards ? .purple.opacity(0.5) : .purple)
                            .cornerRadius(25)
                            .frame(width: 122, height: 32)
                        
                        Text("Rewards")
                            .foregroundColor(Color.white)
                    }
                }

                Button(action: {
                    //showRewards = false
                }) {
                    ZStack {
                        Rectangle()
                            .foregroundColor(showRewards ? .purple : .purple.opacity(0.5))
                            .cornerRadius(25)
                            .frame(width: 122, height: 32)
                        
                        Text("How to?")
                            .foregroundColor(Color.white)
                    }
                }
            }
      
        }
      */
            Text("dawdawd")
    }
     
       
   
}

struct ProfileBannerView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileBannerView()
    }
}

}
