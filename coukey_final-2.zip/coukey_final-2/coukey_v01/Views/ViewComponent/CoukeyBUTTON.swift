//
//  CoukeyBUTTON.swift
//  coukey_v01
//
//  Created by Student on 02.07.23.
//

import SwiftUI
/**
 That button is a generic, so it is a reusable view, u can call it and send the approbiat contents
 **/
struct CoukeyBUTTON: View {
    let title : String
    let background : Color
    let action: () -> Void
    
    var body: some View {
        Button {
            action()
        } label: {
            ZStack {
                RoundedRectangle(cornerRadius: 25)
                    .foregroundColor(background)
                Text(title)
                    .foregroundColor(Color.white)
                    .font(.system(size:19, weight: (.bold)))
            }
        }
    }
}

struct CoukeyBUTTON_Previews: PreviewProvider {
    static var previews: some View {
        CoukeyBUTTON(title: "btn_text", background: .pink){//action
                  }
    }
}
