//
//  CoukingStepsStatsView.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 29.06.23.
//
//
import SwiftUI

struct CoukingStepsStatsView: View {
    
    let stepAmount : Int?
    let servingTime : Int?
    let healthScore : Int?
    let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
    let colorYellow = Color(red: 0.89, green: 0.71, blue: 0.02)
    
    var body: some View {
        HStack{
            
            Circle()
                .stroke(colorYellow, lineWidth: 4)
                .frame(width: 74, height: 74)
                .foregroundColor(colorYellow)
                .overlay(
                    Text(String(healthScore ?? 1))
                    .font(
                    Font.custom("Inter", size: 12)
                    .weight(.bold)
                    )
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                )

            Circle()
                .stroke(colorYellow, lineWidth: 4)
                .frame(width: 74, height: 74)
                .overlay(
                    Text(String(stepAmount ?? 1))
                    .font(
                    Font.custom("Inter", size: 12)
                    .weight(.bold)
                    )
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                )
            Circle()
                .stroke(colorYellow, lineWidth: 4)
                .frame(width: 74, height: 74)
                .foregroundColor(colorYellow)
                .overlay(
                    Text(String(servingTime ?? 1))
                    .font(
                    Font.custom("Inter", size: 12)
                    .weight(.bold)
                    )
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                )

                    
        }
    }
}

struct CoukingStepsStatsView_Previews: PreviewProvider {
    static var previews: some View {
        CoukingStepsStatsView(stepAmount: 1, servingTime: 1, healthScore: 1)
    }
}
