//
//  RecipCounterView.swift
//  coukey_v01
//
//  Created by Fynn Fenton on 29.06.23.
//
//
import SwiftUI



struct RecipCounterView: View {
   
    @Binding var count: Int
    
    let colorLax = Color(red: 1, green: 0.65, blue: 0.65)
    let colorYellow = Color(red: 0.89, green: 0.71, blue: 0.02)
    
    var body: some View {
        HStack{
            
            Circle()
                .frame(width: 40, height: 40)
                .foregroundColor(colorYellow.opacity(count > 1 ? 1.0 : 0.3))
                .overlay(
                    Image(systemName: "minus")
                        .foregroundColor(.white)
                       // .font(.system(size: ))

                )
                .onTapGesture {
                    if count > 1 {
                        count -= 1
                    }
                    
                }
            Circle()
                .stroke(colorYellow, lineWidth: 4)
                .frame(width: 74, height: 74)
                .overlay(
                    Text("\(count)")
                        .foregroundColor(.white)
                        .font(.system(size:30 ))
                )
            Circle()
                .frame(width: 40, height: 40)
                .foregroundColor(colorYellow.opacity(count < 10 ? 1.0 : 0.3))
                .overlay(
                    Image(systemName: "plus")
                        .foregroundColor(.white)
                )
                .onTapGesture {
                    if count < 10{
                        count += 1
                    }
                    
                }
                    
        }
    }
}

struct RecipCounterView_Previews: PreviewProvider {
    static var previews: some View {
        RecipCounterView(count: .constant(1))
   
    }
}

