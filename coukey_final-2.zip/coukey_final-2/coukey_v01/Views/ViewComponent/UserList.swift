//
//  UserList.swift
//  coukey_v01
//
//  Created by Lucas Hoge on 02.07.23.
//

import SwiftUI

struct UserList: View {
    //Authentification viewmodel import
    @EnvironmentObject var viewModel : Authentification_VM
    
    //Bindings and states to link to the edit button in top navigation bar
    @Binding var isDisabled : Bool
    @State var sheetIsPrensented : Bool = false
    
    init(isDisabled : Binding<Bool>){
        self._isDisabled = isDisabled
        UITableView.appearance().backgroundColor = .clear
    }

    
    var body: some View {
        ScrollView{
            ZStack {
                    VStack(alignment: .leading, spacing: 0.0) {
                        
                        //Userlist/settings form
                        Group{
                            Text("Username")
                                .padding(.leading, 8)
                                .padding(7)
                                .foregroundColor(Color("Lax"))
                            HStack{
                                //Authentification_VM binding to sync data in the textfields
                                TextField("Name", text: $viewModel.currentUserName).padding(.leading, 10).foregroundColor(.gray)
                                    .disabled(isDisabled)
                            }.RoundedTextfieldStyle02()
                        
                            Text("Email")
                                .padding(.leading, 8)
                                .padding(7)
                                .foregroundColor(Color("Lax"))
                            HStack{
                                TextField("Email", text: $viewModel.currentUserMail).padding(.leading, 10).foregroundColor(.gray)
                                    .disabled(isDisabled)
                            }.RoundedTextfieldStyle02()
                        
                            Text("Phone")
                                .padding(.leading, 8)
                                .padding(7)
                                .foregroundColor(Color("Lax"))
                            HStack{
                                TextField("Phone", text: $viewModel.currentUserPhone).padding(.leading, 10).foregroundColor(.gray)
                                    .disabled(isDisabled)
                            }.RoundedTextfieldStyle02()
                        
                            Text("Password")
                                .padding(.leading, 8)
                                .padding(7)
                                .foregroundColor(Color("Lax"))
                            HStack{
                                SecureField("Password", text: $viewModel.password).padding(.leading, 10).foregroundColor(.gray)
                                    .disabled(isDisabled)
                            }.RoundedTextfieldStyle02()
                        
                            Text("Confirm Password")
                                .padding(.leading, 8)
                                .padding(7)
                                .foregroundColor(Color("Lax"))
                            HStack{
                                SecureField("Confirm Password", text: $viewModel.confirmPassword).padding(.leading, 10).foregroundColor(.gray)
                                    .disabled(isDisabled)
                            }.RoundedTextfieldStyle02()
                        }
                            //Save Changes Button
                            Button{
                                // Saves changes to the persistent store
                                viewModel.updateAccount()
                            } label:{
                                
                                ZStack{
                                    Rectangle()
                                        .listRowSeparator(.hidden)
                                        .frame(height: 34.0)

                                        .foregroundColor(isDisabled ? Color(.gray) : Color("Purple"))
                                        
                                        .cornerRadius(25)
                                    Text("Save Changes")
                                        .font(.system(size:19, weight: (.bold)))
                                        .foregroundColor(Color.white)
                                }
                            }
                            .padding(.vertical, 20.0)
                        
                        //Verify account button
                        Button{
                            //If user is not verifified by phone
                            //VM_verifyByPhone function & Show verify sheet
                            if !viewModel.currentUserPhone.isEmpty{
                                viewModel.verifyByPhone()
                                sheetIsPrensented = true
                            } 
                            
                        } label:{
                            
                            ZStack{
                                Rectangle()
                                    .listRowSeparator(.hidden)
                                    .frame(height: 34.0)

                                    
                                    
                                    .foregroundColor(Color("LightLax"))
                                    .cornerRadius(25)
                                Text("Verify Account")
                                    .font(.system(size:19, weight: (.bold)))
                                    .foregroundColor(Color.white)
                            }
                        }
                        .padding(.vertical, 3.0)
                      
                        
                    }
                    .padding(.horizontal, 40.0)
                    .padding(.top, 15.0)
                    
            }
        }.sheet(isPresented: $sheetIsPrensented){
            VerifySheetView()
            
        }
        
    }
}

struct UserList_Previews: PreviewProvider {
    static var previews: some View {
        UserList(isDisabled: .constant(true))
    }
}
