//
//  File.swift
//  coukey_v01
//
//  Created by Student on 29.06.23.
//

import Foundation

//MARK: RECIPEINFORESPONSE ARRAY
/*
typealias recipeInfos = [RecipeInfo]


//MARK: RecipeInfo
struct RecipeInfo: Codable , Hashable {
    let vegetarian, vegan, glutenFree, dairyFree: Bool
    let veryHealthy, cheap, veryPopular, sustainable: Bool
    let lowFodmap: Bool
    let weightWatcherSmartPoints: Int
    let gaps: String
    let preparationMinutes, cookingMinutes, aggregateLikes, healthScore: Int
    let creditsText, sourceName: String
    let pricePerServing: Double
    //let extendedIngredients: [ExtendedIngredient]
    let id: Int
    let title: String
    let readyInMinutes, servings: Int
    //let sourceURL: String
    let image: String
    //let imageType, summary: String
    //let cuisines: [JSONAny]
    //let dishTypes, diets: [String]
    //let occasions: [JSONAny]
    //let winePairing: WinePairing
    let instructions: String
    //let analyzedInstructions: [AnalyzedInstruction]
    //let originalID: JSONNull?
    //let spoonacularSourceURL: String

}
*/ //deprecated
