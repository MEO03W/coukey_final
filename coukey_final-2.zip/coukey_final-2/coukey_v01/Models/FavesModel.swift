//
//  FavesModel.swift
//  coukey_v01
//
//  Created by Student on 11.07.23.
//

import Foundation


//our favorites
struct Faves : Codable {
    var recipeID : [Int]
}
    
