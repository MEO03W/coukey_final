//
//  MergedRecipeModel.swift
//  coukey_v01
//
//  Created by Student on 01.07.23.
//

import Foundation


// MARK: - Recipes
struct Recipes: Codable {
    var results: [Result]
    let offset, number, totalResults: Int
}

// MARK: - Result
struct Result: Codable {
    let vegetarian, vegan, glutenFree, dairyFree: Bool
    let veryHealthy, cheap, veryPopular, sustainable: Bool
    let lowFodmap: Bool?
    let weightWatcherSmartPoints: Int?
    //let gaps: Gaps
    let preparationMinutes, cookingMinutes, aggregateLikes, healthScore: Int?
    let creditsText, sourceName: String?
    let pricePerServing: Double?
    let id: Int
    let title: String
    let readyInMinutes, servings: Int
    let sourceURL: String?
    let image: String
    let imageType: ImageType
    let summary: String?
    let cuisines: [String]?
    let dishTypes, diets, occasions: [String]
    let extendedIngredients: [EdIngredient]
    let analyzedInstructions: [AnalyzedInstruction]
    let spoonacularSourceURL: String?
    let license: String?

    /*enum CodingKeys: String, CodingKey {
        case vegetarian, vegan, glutenFree, dairyFree, veryHealthy, cheap, veryPopular, sustainable, lowFodmap, weightWatcherSmartPoints, gaps, preparationMinutes, cookingMinutes, aggregateLikes, healthScore, creditsText, sourceName, pricePerServing, id, title, readyInMinutes, servings
        case sourceURL
        case image, imageType, summary, cuisines, dishTypes, diets, occasions, analyzedInstructions
        case spoonacularSourceURL
        case license
    }*/
}

// MARK: - AnalyzedInstruction
struct AnalyzedInstruction: Codable {
    let name: String
    let steps: [Step]
}

// MARK: - Step
struct Step: Codable {
    let number: Int
    let step: String
    let ingredients, equipment: [Ent]
    let length: Length?
}

// MARK: - Ent
struct Ent: Codable {
    let id: Int
    let name, localizedName, image: String
}

// MARK: - Length
struct Length: Codable {
    let number: Int
    let unit: Unit
}

enum Unit: String, Codable {
    case minutes = "minutes"
}

/*enum Gaps: String, Codable {
    case gaps4 = "GAPS_4"
    case no = "no"
}*/

enum ImageType: String, Codable {
    case jpg = "jpg"
}
//MARK: Ingredient
struct EdIngredient: Codable, Hashable {
    let id: Int
    let aisle: String?
    let image: String?
    //let consistency: Consistency?
    let name: String
    let nameClean: String?
    let original, originalName: String
    let amount: Double
    let unit: String
    let meta: [String]
    let measures: Measures?
    let unitLong, unitShort, extendedName: String?
    
    //what you want to include in the hasher
    //dont take the things which need other structs bc they'll need to be hashable as well,
    //should be enough to compare all other attributes
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(aisle)
        hasher.combine(image)
        hasher.combine(name)
        hasher.combine(nameClean)
        hasher.combine(original)
        hasher.combine(originalName)
        hasher.combine(amount)
        hasher.combine(unit)
        hasher.combine(meta)
        //hasher.combine(measures)
        hasher.combine(unitLong)
        hasher.combine(unitShort)
        hasher.combine(extendedName)
    }
    //lefthashside,righthashside
    static func == (lhs: EdIngredient, rhs: EdIngredient) -> Bool {
        return lhs.id == rhs.id &&
            lhs.aisle == rhs.aisle &&
            lhs.image == rhs.image &&
            lhs.name == rhs.name &&
            lhs.nameClean == rhs.nameClean &&
            lhs.original == rhs.original &&
            lhs.originalName == rhs.originalName &&
            lhs.amount == rhs.amount &&
            lhs.unit == rhs.unit &&
            lhs.meta == rhs.meta &&
            //lhs.measures == rhs.measures &&
            lhs.unitLong == rhs.unitLong &&
            lhs.unitShort == rhs.unitShort &&
            lhs.extendedName == rhs.extendedName
    }

}
//**MAKE IT HASHABLE



//MARK: Measure
struct Measures: Codable {
    let us, metric: Metric
}
//MARK: Metric 
// MARK: - Metric
struct Metric: Codable {
    let amount: Double
    let unitShort, unitLong: String
}
