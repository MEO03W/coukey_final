//
//  RecipeShortModel.swift
//  coukey_v01
//
//  Created by Paul/Student on 20.05.23.
//

import Foundation
/*
// MARK: - Welcome
struct RecipeResponse: Codable {
    let results: [Result]
    let offset, number, totalResults: Int
}

// MARK: - Result
struct Result: Codable, Hashable {
    let id: Int
    let title: String
    let image: String
    let imageType: ImageType
}

enum ImageType: String, Codable {
    case jpg = "jpg"
}
*/ //decprecated
